import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  updateDoc, 
  increment,
  query
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Product, Post, CartItem, Report } from '../types';
import { SAMPLE_PRODUCTS } from '../data/sampleData';
import { useAuth } from './AuthContext';

interface MarketplaceContextType {
  products: Product[];
  posts: Post[];
  favorites: string[];
  isFavorite: (productId: string) => boolean;
  toggleFavorite: (productId: string) => Promise<void>;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, color?: string, size?: string) => void;
  removeFromCart: (productId: string, color?: string) => void;
  updateCartQuantity: (productId: string, quantity: number, color?: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  activeCurrency: string;
  setActiveCurrency: (cur: string) => void;
  currenciesList: CurrencyInfo[];
  formatPrice: (amount: number, fromCurrency?: string) => string;
  createProductListing: (product: Omit<Product, 'id' | 'createdAt' | 'sellerId' | 'sellerName' | 'sellerUsername'>) => Promise<string>;
  updateProductStock: (productId: string, newStock: number) => Promise<void>;
  deleteProduct: (productId: string) => Promise<void>;
  likeProduct: (productId: string) => Promise<void>;
  createPostPublication: (content: string, imageURL?: string, taggedProduct?: Product) => Promise<string>;
  likePost: (postId: string) => Promise<void>;
  submitReport: (targetType: 'product' | 'post' | 'user', targetId: string, reason: string, details?: string) => Promise<void>;
  isAdmin: boolean;
  loading: boolean;
}

export interface CurrencyInfo {
  code: string;
  symbol: string;
  nameAr: string;
  nameEn: string;
  flag: string;
  rateToUSD: number;
  decimals: number;
}

export const SUPPORTED_CURRENCIES: CurrencyInfo[] = [
  { code: 'IQD', symbol: 'د.ع', nameAr: 'دينار عراقي', nameEn: 'Iraqi Dinar', flag: '🇮🇶', rateToUSD: 1310, decimals: 0 },
  { code: 'SAR', symbol: 'ر.س', nameAr: 'ريال سعودي', nameEn: 'Saudi Riyal', flag: '🇸🇦', rateToUSD: 3.75, decimals: 2 },
  { code: 'AED', symbol: 'د.إ', nameAr: 'درهم إماراتي', nameEn: 'UAE Dirham', flag: '🇦🇪', rateToUSD: 3.67, decimals: 2 },
  { code: 'KWD', symbol: 'د.ك', nameAr: 'دينار كويتي', nameEn: 'Kuwaiti Dinar', flag: '🇰🇼', rateToUSD: 0.31, decimals: 3 },
  { code: 'QAR', symbol: 'ر.ق', nameAr: 'ريال قطري', nameEn: 'Qatari Riyal', flag: '🇶🇦', rateToUSD: 3.64, decimals: 2 },
  { code: 'BHD', symbol: 'د.ب', nameAr: 'دينار بحريني', nameEn: 'Bahraini Dinar', flag: '🇧🇭', rateToUSD: 0.376, decimals: 3 },
  { code: 'OMR', symbol: 'ر.ع', nameAr: 'ريال عماني', nameEn: 'Omani Rial', flag: '🇴🇲', rateToUSD: 0.385, decimals: 3 },
  { code: 'JOD', symbol: 'د.أ', nameAr: 'دينار أردني', nameEn: 'Jordanian Dinar', flag: '🇯🇴', rateToUSD: 0.71, decimals: 2 },
  { code: 'EGP', symbol: 'ج.م', nameAr: 'جنيه مصري', nameEn: 'Egyptian Pound', flag: '🇪🇬', rateToUSD: 48.5, decimals: 2 },
  { code: 'USD', symbol: '$', nameAr: 'دولار أمريكي', nameEn: 'US Dollar', flag: '🇺🇸', rateToUSD: 1.0, decimals: 2 },
  { code: 'EUR', symbol: '€', nameAr: 'يورو', nameEn: 'Euro', flag: '🇪🇺', rateToUSD: 0.92, decimals: 2 },
  { code: 'GBP', symbol: '£', nameAr: 'جنيه إسترليني', nameEn: 'British Pound', flag: '🇬🇧', rateToUSD: 0.79, decimals: 2 },
  { code: 'TRY', symbol: '₺', nameAr: 'ليرة تركية', nameEn: 'Turkish Lira', flag: '🇹🇷', rateToUSD: 34.0, decimals: 2 },
  { code: 'JPY', symbol: '¥', nameAr: 'ين ياباني', nameEn: 'Japanese Yen', flag: '🇯🇵', rateToUSD: 154.0, decimals: 0 }
];

const CURRENCY_RATES: Record<string, number> = SUPPORTED_CURRENCIES.reduce((acc, c) => {
  acc[c.code] = c.rateToUSD;
  return acc;
}, {} as Record<string, number>);

const CURRENCY_SYMBOLS: Record<string, string> = SUPPORTED_CURRENCIES.reduce((acc, c) => {
  acc[c.code] = c.symbol;
  return acc;
}, {} as Record<string, string>);

const MarketplaceContext = createContext<MarketplaceContextType | undefined>(undefined);

export const MarketplaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, userProfile } = useAuth();
  const [firestoreProducts, setFirestoreProducts] = useState<Product[]>([]);
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('aura_favorites');
      return saved ? JSON.parse(saved) : ['sample-p1', 'sample-p2'];
    } catch {
      return ['sample-p1', 'sample-p2'];
    }
  });
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('aura_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activeCurrency, setActiveCurrencyState] = useState<string>(() => {
    try {
      return localStorage.getItem('aiushub_currency') || localStorage.getItem('aura_currency') || 'USD';
    } catch {
      return 'USD';
    }
  });
  const [loading, setLoading] = useState(true);

  const setActiveCurrency = (cur: string) => {
    setActiveCurrencyState(cur);
    try {
      localStorage.setItem('aiushub_currency', cur);
    } catch (e) {
      console.warn("Storage notice:", e);
    }
  };

  // Admin secret identity check: Only user's email cl4sc4@gmail.com
  const isAdmin = useMemo(() => {
    return user?.email === 'cl4sc4@gmail.com';
  }, [user]);

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('aura_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn("Storage quota:", e);
    }
  }, [cart]);

  // Sync favorites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('aura_favorites', JSON.stringify(favorites));
    } catch (e) {
      console.warn("Storage quota:", e);
    }
  }, [favorites]);

  // Real-time Firestore Products listener
  useEffect(() => {
    const productsPath = 'products';
    const productsQuery = query(collection(db, productsPath));
    const unsubscribe = onSnapshot(
      productsQuery,
      (snapshot) => {
        const items: Product[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...docSnap.data() } as Product);
        });
        // Sort newest first
        items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setFirestoreProducts(items);
        setLoading(false);
      },
      (error) => {
        console.warn("Products sync notice:", error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Merged products: Real products from Cloud Firestore + exactly 2 sample products
  const products = useMemo(() => {
    return [...firestoreProducts, ...SAMPLE_PRODUCTS];
  }, [firestoreProducts]);

  const isFavorite = (productId: string) => favorites.includes(productId);

  const toggleFavorite = async (productId: string) => {
    const isFav = favorites.includes(productId);
    const updated = isFav ? favorites.filter((id) => id !== productId) : [...favorites, productId];
    setFavorites(updated);

    if (user) {
      const favDocId = `${user.uid}_${productId}`;
      const favRef = doc(db, 'favorites', favDocId);
      try {
        if (isFav) {
          await deleteDoc(favRef);
        } else {
          await setDoc(favRef, {
            userId: user.uid,
            productId,
            createdAt: new Date().toISOString()
          });
        }
      } catch (err) {
        console.warn("Favorite Firestore notice:", err);
      }
    }
  };

  const likeProduct = async (productId: string) => {
    // Toggle in favorites
    await toggleFavorite(productId);

    // If it's a real product, increment likesCount in Firestore
    if (!productId.startsWith('sample-')) {
      const prodRef = doc(db, 'products', productId);
      try {
        await updateDoc(prodRef, {
          likesCount: increment(1)
        });
      } catch (err) {
        console.warn("Could not increment like count:", err);
      }
    } else {
      // Local sample increment
      const s = SAMPLE_PRODUCTS.find(p => p.id === productId);
      if (s) s.likesCount = (s.likesCount || 0) + 1;
    }
  };

  // Seller stock editing: Only stock can be edited by seller!
  const updateProductStock = async (productId: string, newStock: number) => {
    if (!user) throw new Error("Must be signed in to update stock");
    const stockVal = Math.max(0, Math.floor(newStock));

    if (productId.startsWith('sample-')) {
      const sample = SAMPLE_PRODUCTS.find(p => p.id === productId);
      if (sample) sample.stock = stockVal;
      return;
    }

    const prodRef = doc(db, 'products', productId);
    try {
      await updateDoc(prodRef, {
        stock: stockVal,
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `products/${productId}`);
    }
  };

  // Delete product (by Admin cl4sc4@gmail.com or Seller)
  const deleteProduct = async (productId: string) => {
    if (!user) throw new Error("Must be signed in to delete products");

    if (productId.startsWith('sample-')) {
      const index = SAMPLE_PRODUCTS.findIndex(p => p.id === productId);
      if (index > -1) SAMPLE_PRODUCTS.splice(index, 1);
      return;
    }

    const prodRef = doc(db, 'products', productId);
    try {
      await deleteDoc(prodRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `products/${productId}`);
    }
  };

  const addToCart = (product: Product, quantity = 1, color?: string, size?: string) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedColor === color && item.selectedSize === size
      );
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity
        };
        return next;
      }
      return [...prev, { product, quantity, selectedColor: color, selectedSize: size }];
    });
  };

  const removeFromCart = (productId: string, color?: string) => {
    setCart((prev) => prev.filter((item) => !(item.product.id === productId && (!color || item.selectedColor === color))));
  };

  const updateCartQuantity = (productId: string, quantity: number, color?: string) => {
    if (quantity <= 0) {
      removeFromCart(productId, color);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId && (!color || item.selectedColor === color)) {
          return { ...item, quantity };
        }
        return item;
      })
    );
  };

  const clearCart = () => setCart([]);

  const cartCount = useMemo(() => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  }, [cart]);

  const cartSubtotal = useMemo(() => {
    return cart.reduce((total, item) => total + item.product.price * item.quantity, 0);
  }, [cart]);

  const formatPrice = (amount: number, fromCurrency = 'USD') => {
    const fromRate = CURRENCY_RATES[fromCurrency] || 1;
    const toRate = CURRENCY_RATES[activeCurrency] || 1;
    const baseAmountInUSD = fromCurrency === 'USD' ? amount : amount / fromRate;
    const targetAmount = baseAmountInUSD * toRate;
    const currInfo = SUPPORTED_CURRENCIES.find(c => c.code === activeCurrency) || {
      code: activeCurrency,
      symbol: '$',
      decimals: 2
    };

    if (currInfo.decimals === 0) {
      return `${Math.round(targetAmount).toLocaleString()} ${currInfo.symbol}`;
    }

    if (currInfo.code === 'USD') {
      return `$${targetAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    if (currInfo.code === 'EUR') {
      return `€${targetAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    if (currInfo.code === 'GBP') {
      return `£${targetAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }

    return `${targetAmount.toLocaleString(undefined, { minimumFractionDigits: currInfo.decimals, maximumFractionDigits: currInfo.decimals })} ${currInfo.symbol}`;
  };

  const createProductListing = async (
    productData: Omit<Product, 'id' | 'createdAt' | 'sellerId' | 'sellerName' | 'sellerUsername'>
  ): Promise<string> => {
    if (!user) throw new Error("Must be signed in to publish a product");

    const newId = `prod_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const rawProduct: Record<string, any> = {
      ...productData,
      id: newId,
      sellerId: user.uid,
      sellerName: userProfile?.displayName || user.displayName || 'Marketplace Seller',
      sellerUsername: userProfile?.username || (user.email?.split('@')[0] || 'seller'),
      sellerAvatar: userProfile?.photoURL || user.photoURL || '',
      category: productData.category || 'عام',
      condition: productData.condition || 'جديد',
      rating: 5.0,
      reviewCount: 1,
      likesCount: 0,
      stock: productData.stock !== undefined ? productData.stock : 1,
      isSample: false,
      createdAt: new Date().toISOString()
    };

    // Remove any undefined keys to avoid Firestore unsupported field value errors
    const cleanedProduct: Record<string, any> = {};
    for (const [key, val] of Object.entries(rawProduct)) {
      if (val !== undefined) {
        cleanedProduct[key] = val;
      }
    }

    try {
      await setDoc(doc(db, 'products', newId), cleanedProduct);
      return newId;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `products/${newId}`);
    }
  };

  const createPostPublication = async (
    content: string, 
    imageURL?: string, 
    taggedProduct?: Product
  ): Promise<string> => {
    if (!user) throw new Error("Must be signed in to publish a post");

    const newId = `post_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newPost: Post = {
      id: newId,
      authorId: user.uid,
      authorName: userProfile?.displayName || user.displayName || 'Marketplace Member',
      authorUsername: userProfile?.username || (user.email?.split('@')[0] || 'member'),
      authorAvatar: userProfile?.photoURL || user.photoURL || '',
      content: content.trim(),
      imageURL: imageURL || '',
      taggedProductId: taggedProduct?.id || '',
      taggedProductTitle: taggedProduct?.title || '',
      likesCount: 0,
      commentsCount: 0,
      isSample: false,
      createdAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'posts', newId), newPost);
      return newId;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `posts/${newId}`);
    }
  };

  const likePost = async (postId: string) => {
    if (postId.startsWith('sample-')) return;
    const postRef = doc(db, 'posts', postId);
    try {
      await updateDoc(postRef, {
        likesCount: increment(1)
      });
    } catch (error) {
      console.warn("Could not like post:", error);
    }
  };

  const submitReport = async (
    targetType: 'product' | 'post' | 'user',
    targetId: string,
    reason: string,
    details?: string
  ) => {
    if (!user) throw new Error("Please sign in to submit a safety report.");
    const newId = `rep_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const reportData: Report = {
      id: newId,
      reporterId: user.uid,
      targetType,
      targetId,
      reason,
      details: details || '',
      status: 'open',
      createdAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'reports', newId), reportData);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `reports/${newId}`);
    }
  };

  return (
    <MarketplaceContext.Provider
      value={{
        products,
        posts: [],
        favorites,
        isFavorite,
        toggleFavorite,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        activeCurrency,
        setActiveCurrency,
        currenciesList: SUPPORTED_CURRENCIES,
        formatPrice,
        createProductListing,
        updateProductStock,
        deleteProduct,
        likeProduct,
        createPostPublication,
        likePost,
        submitReport,
        isAdmin,
        loading
      }}
    >
      {children}
    </MarketplaceContext.Provider>
  );
};

export const useMarketplace = () => {
  const context = useContext(MarketplaceContext);
  if (!context) {
    throw new Error('useMarketplace must be used within a MarketplaceProvider');
  }
  return context;
};
