import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  updateDoc, 
  query, 
  where,
  orderBy 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { Conversation, Message, Product } from '../types';
import { SAMPLE_CONVERSATION, SAMPLE_MESSAGES } from '../data/sampleData';
import { useAuth } from './AuthContext';

interface MessagingContextType {
  conversations: Conversation[];
  activeConversation: Conversation | null;
  setActiveConversation: (conv: Conversation | null) => void;
  messages: Message[];
  startConversation: (sellerId: string, sellerName: string, product?: Product) => Promise<Conversation>;
  sendMessage: (text: string) => Promise<void>;
  loading: boolean;
}

const MessagingContext = createContext<MessagingContextType | undefined>(undefined);

export const MessagingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, userProfile } = useAuth();
  const [firestoreConversations, setFirestoreConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);

  // Sync user conversations from Firestore
  useEffect(() => {
    if (!user) {
      setFirestoreConversations([]);
      return;
    }

    const convPath = 'conversations';
    const convQuery = query(
      collection(db, convPath),
      where('participantIds', 'array-contains', user.uid)
    );

    const unsubscribe = onSnapshot(
      convQuery,
      (snapshot) => {
        const list: Conversation[] = [];
        snapshot.forEach((docSnap) => {
          list.push({ id: docSnap.id, ...docSnap.data() } as Conversation);
        });
        // Sort descending by lastMessageAt
        list.sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime());
        setFirestoreConversations(list);
      },
      (error) => {
        console.warn("Conversations listener notice:", error);
      }
    );

    return () => unsubscribe();
  }, [user]);

  // Merge sample conversation if user has no conversations yet or for exploration
  const conversations = React.useMemo(() => {
    if (firestoreConversations.length > 0) return firestoreConversations;
    return [SAMPLE_CONVERSATION];
  }, [firestoreConversations]);

  // Sync messages for active conversation
  useEffect(() => {
    if (!activeConversation) {
      setMessages([]);
      return;
    }

    // If active conversation is sample conversation, load sample messages
    if (activeConversation.id === SAMPLE_CONVERSATION.id) {
      setMessages(SAMPLE_MESSAGES);
      return;
    }

    const messagesPath = `conversations/${activeConversation.id}/messages`;
    const messagesQuery = query(
      collection(db, messagesPath)
    );

    const unsubscribe = onSnapshot(
      messagesQuery,
      (snapshot) => {
        const list: Message[] = [];
        snapshot.forEach((docSnap) => {
          list.push({ id: docSnap.id, ...docSnap.data() } as Message);
        });
        list.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        setMessages(list);
      },
      (error) => {
        console.warn("Messages listener notice:", error);
      }
    );

    return () => unsubscribe();
  }, [activeConversation]);

  const startConversation = async (
    sellerId: string, 
    sellerName: string, 
    product?: Product
  ): Promise<Conversation> => {
    const currentUid = user ? user.uid : 'guest-user';
    const currentName = userProfile?.displayName || user?.displayName || 'Interested Buyer';

    // Check if matching conversation already exists
    const existing = conversations.find(c => 
      c.participantIds.includes(sellerId) && 
      (product ? c.productId === product.id : true)
    );

    if (existing) {
      setActiveConversation(existing);
      return existing;
    }

    const convId = `conv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newConv: Conversation = {
      id: convId,
      participantIds: [currentUid, sellerId],
      participantNames: [currentName, sellerName],
      lastMessage: product ? `Inquiring about ${product.title}` : 'Started a conversation',
      lastMessageAt: new Date().toISOString(),
      productId: product?.id,
      productTitle: product?.title,
      isSample: false,
      createdAt: new Date().toISOString()
    };

    if (user) {
      try {
        await setDoc(doc(db, 'conversations', convId), newConv);
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `conversations/${convId}`);
      }
    } else {
      // Local fallback for guest
      setFirestoreConversations(prev => [newConv, ...prev]);
    }

    setActiveConversation(newConv);
    return newConv;
  };

  const sendMessage = async (text: string) => {
    if (!activeConversation || !text.trim()) return;

    const currentUid = user ? user.uid : 'guest-user';
    const currentName = userProfile?.displayName || user?.displayName || 'You';
    const msgId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const nowIso = new Date().toISOString();

    const newMsg: Message = {
      id: msgId,
      conversationId: activeConversation.id,
      senderId: currentUid,
      senderName: currentName,
      text: text.trim(),
      createdAt: nowIso
    };

    if (activeConversation.id === SAMPLE_CONVERSATION.id) {
      // Local demo message
      setMessages(prev => [...prev, newMsg]);
      return;
    }

    if (user) {
      try {
        await setDoc(doc(db, `conversations/${activeConversation.id}/messages`, msgId), newMsg);
        await updateDoc(doc(db, 'conversations', activeConversation.id), {
          lastMessage: text.trim().slice(0, 500),
          lastMessageAt: nowIso
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `conversations/${activeConversation.id}/messages/${msgId}`);
      }
    } else {
      setMessages(prev => [...prev, newMsg]);
    }
  };

  return (
    <MessagingContext.Provider
      value={{
        conversations,
        activeConversation,
        setActiveConversation,
        messages,
        startConversation,
        sendMessage,
        loading
      }}
    >
      {children}
    </MessagingContext.Provider>
  );
};

export const useMessaging = () => {
  const context = useContext(MessagingContext);
  if (!context) {
    throw new Error('useMessaging must be used within a MessagingProvider');
  }
  return context;
};
