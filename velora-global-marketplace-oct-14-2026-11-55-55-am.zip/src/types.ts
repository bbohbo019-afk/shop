export interface ProductColor {
  name: string;
  hex: string;
  bgTint: string;
}

export interface Product {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerUsername: string;
  sellerAvatar?: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  category: string;
  condition: string;
  country?: string;
  city?: string;
  images: string[];
  colors?: string[]; // hex codes or labels
  colorDetails?: ProductColor[];
  sizes?: string[];
  backgroundTint?: string;
  rating?: number;
  reviewCount?: number;
  contactPreference?: string;
  contactInfo?: string;
  isSample?: boolean;
  stock?: number;
  whatsapp?: string;
  telegram?: string;
  websiteUrl?: string;
  likesCount?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface UserProfile {
  id: string;
  displayName: string;
  username: string;
  email: string;
  photoURL?: string;
  bio?: string;
  country?: string;
  city?: string;
  isVerified?: boolean;
  createdAt: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername?: string;
  authorAvatar?: string;
  content: string;
  imageURL?: string;
  taggedProductId?: string;
  taggedProductTitle?: string;
  likesCount: number;
  commentsCount: number;
  isSample?: boolean;
  createdAt: string;
  likedByCurrentUser?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participantNames: string[];
  lastMessage: string;
  lastMessageAt: string;
  productId?: string;
  productTitle?: string;
  isSample?: boolean;
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  text: string;
  createdAt: string;
}

export interface Report {
  id: string;
  reporterId: string;
  targetType: 'product' | 'post' | 'user';
  targetId: string;
  reason: string;
  details?: string;
  status: string;
  createdAt: string;
}
