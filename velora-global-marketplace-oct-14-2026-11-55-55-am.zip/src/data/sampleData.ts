import { Product, Post, Conversation, Message } from '../types';

// Exactly 2 curated demonstration items per user request
export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 'sample-p1',
    sellerId: 'sample-seller-1',
    sellerName: 'Studio Nordique',
    sellerUsername: 'studionordique',
    sellerAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    title: 'AURA Sphere ANC Headphones',
    description: 'Precision engineered wireless headphones with spatial audio tracking, custom 40mm beryllium drivers, active ambient suppression, and an ultralight aerospace magnesium alloy headband. Features up to 38 hours of lossless listening on a single charge.',
    price: 349,
    currency: 'USD',
    category: 'Audio & Studio',
    condition: 'Brand New',
    country: 'Denmark',
    city: 'Copenhagen',
    stock: 4,
    whatsapp: '+4512345678',
    telegram: 'studionordique',
    websiteUrl: 'https://studionordique.example.com',
    likesCount: 88,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&auto=format&fit=crop&q=80'
    ],
    colors: ['#E2DFD8', '#1E2229', '#C2A68C'],
    colorDetails: [
      { name: 'Oatmeal Mist', hex: '#E2DFD8', bgTint: '#EAE6DF' },
      { name: 'Obsidian Noir', hex: '#1E2229', bgTint: '#E2E4E8' },
      { name: 'Desert Caramel', hex: '#C2A68C', bgTint: '#F3ECE3' }
    ],
    sizes: ['Standard Over-Ear', 'Compact Travel'],
    backgroundTint: '#EAE6DF',
    rating: 4.9,
    reviewCount: 38,
    contactPreference: 'WhatsApp',
    contactInfo: '+4512345678',
    isSample: true,
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString()
  },
  {
    id: 'sample-p2',
    sellerId: 'sample-seller-2',
    sellerName: 'Horology Atelier',
    sellerUsername: 'horologyatelier',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    title: 'Chronos Monolith Automatic Watch',
    description: 'Hand-assembled mechanical timepiece featuring an open-heart exhibition caseback, sapphire crystal with triple anti-reflective coating, and an interchangeable full-grain vegetable-tanned calfskin strap. Water resistant to 10 ATM.',
    price: 890,
    currency: 'USD',
    category: 'Watches & Jewelry',
    condition: 'Mint Condition',
    country: 'Switzerland',
    city: 'Geneva',
    stock: 2,
    whatsapp: '+41221234567',
    telegram: 'horologyatelier',
    websiteUrl: 'https://horology.example.com',
    likesCount: 142,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=800&auto=format&fit=crop&q=80'
    ],
    colors: ['#D0D5DD', '#E8C5A5', '#1D2939'],
    colorDetails: [
      { name: 'Brushed Titanium', hex: '#D0D5DD', bgTint: '#E6ECF2' },
      { name: 'Rose Amber', hex: '#E8C5A5', bgTint: '#F6EAE1' },
      { name: 'Midnight Charcoal', hex: '#1D2939', bgTint: '#E1E4EA' }
    ],
    sizes: ['38mm Dial', '41mm Dial'],
    backgroundTint: '#E6ECF2',
    rating: 5.0,
    reviewCount: 24,
    contactPreference: 'Telegram',
    contactInfo: '@horologyatelier',
    isSample: true,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString()
  }
];

export const SAMPLE_POSTS: Post[] = [];

export const SAMPLE_CONVERSATION: Conversation = {
  id: 'sample-conv-1',
  participantIds: ['guest-user', 'sample-seller-1'],
  participantNames: ['You', 'Studio Nordique'],
  lastMessage: 'Hello! You can message us via WhatsApp or Telegram for expedited shipping.',
  lastMessageAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  productId: 'sample-p1',
  productTitle: 'AURA Sphere ANC Headphones',
  isSample: true,
  createdAt: new Date(Date.now() - 86400000).toISOString()
};

export const SAMPLE_MESSAGES: Message[] = [
  {
    id: 'msg-1',
    conversationId: 'sample-conv-1',
    senderId: 'guest-user',
    senderName: 'You',
    text: 'Hello Studio Nordique! Is the Oatmeal Mist colorway in stock and ready to ship?',
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString()
  },
  {
    id: 'msg-2',
    conversationId: 'sample-conv-1',
    senderId: 'sample-seller-1',
    senderName: 'Studio Nordique',
    text: 'Hi! Yes, we have 4 units remaining in stock in Copenhagen.',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
  }
];
