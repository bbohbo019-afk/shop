import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ 
  className = '', 
  size = 44,
  showText = false 
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      {/* Icon Emblem: Futuristic geometric infinity hub symbolizing AI + US + HUB */}
      <div 
        className="relative rounded-2xl bg-gradient-to-br from-stone-950 via-slate-900 to-stone-900 text-white flex items-center justify-center shrink-0 shadow-lg shadow-stone-950/25 ring-1 ring-white/15 overflow-hidden group"
        style={{ width: size, height: size }}
      >
        {/* Soft Ambient Inner Glow */}
        <div className="absolute inset-0 bg-gradient-to-tr from-sky-500/15 via-transparent to-amber-400/20 pointer-events-none" />

        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-[72%] h-[72%] relative z-10 transition-transform duration-300 group-hover:scale-105"
        >
          <defs>
            {/* AIUSHUB Primary Titanium Gradient */}
            <linearGradient id="aiusGradientPrimary" x1="12" y1="14" x2="52" y2="50" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFFFFF" />
              <stop offset="0.45" stopColor="#E2E8F0" />
              <stop offset="0.85" stopColor="#94A3B8" />
              <stop offset="1" stopColor="#64748B" />
            </linearGradient>

            {/* AIUSHUB Electric Accent Glow */}
            <linearGradient id="aiusAccent" x1="20" y1="20" x2="44" y2="44" gradientUnits="userSpaceOnUse">
              <stop stopColor="#38BDF8" />
              <stop offset="0.6" stopColor="#818CF8" />
              <stop offset="1" stopColor="#F472B6" />
            </linearGradient>

            <linearGradient id="goldSheen" x1="16" y1="16" x2="48" y2="48" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FDE047" />
              <stop offset="1" stopColor="#F59E0B" />
            </linearGradient>
          </defs>

          {/* Hexagonal Hub Boundary (Soft subtle structure) */}
          <polygon
            points="32,8 51,19 51,45 32,56 13,45 13,19"
            stroke="#94A3B8"
            strokeWidth="1.2"
            strokeOpacity="0.3"
            strokeDasharray="2 3"
          />

          {/* Left Wing of 'A' and 'H' Flow */}
          <path
            d="M20 46 L20 22 C20 18, 26 15, 32 15 C38 15, 44 18, 44 22 L44 46"
            stroke="url(#aiusGradientPrimary)"
            strokeWidth="3.4"
            strokeLinecap="round"
          />

          {/* Central Crossing Bridge & Hub Node */}
          <path
            d="M17 33 L47 33"
            stroke="url(#aiusAccent)"
            strokeWidth="2.8"
            strokeLinecap="round"
          />

          {/* Central Dynamic Energy Diamond (The 'HUB' Focal Point) */}
          <polygon
            points="32,25 38,33 32,41 26,33"
            fill="url(#aiusGradientPrimary)"
          />

          <circle cx="32" cy="33" r="2.2" fill="#0F172A" />

          {/* Connection Orbital Points */}
          <circle cx="20" cy="46" r="2.2" fill="#38BDF8" />
          <circle cx="44" cy="46" r="2.2" fill="#818CF8" />
          <circle cx="32" cy="15" r="2" fill="#FDE047" />
        </svg>
      </div>

      {/* Optional Integrated Wordmark */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1 leading-none">
            <span className="font-display font-black text-lg tracking-tight text-stone-900">
              AIUS<span className="text-sky-600">HUB</span>
            </span>
          </div>
          <span className="text-[10px] font-bold text-stone-400 tracking-wider uppercase mt-0.5">
            Global Marketplace
          </span>
        </div>
      )}
    </div>
  );
};
