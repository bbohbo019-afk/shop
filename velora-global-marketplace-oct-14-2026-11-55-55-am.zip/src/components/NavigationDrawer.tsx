import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  ShoppingBag, 
  PlusCircle, 
  Heart, 
  MessageSquare, 
  Settings, 
  LogOut, 
  ShieldCheck, 
  ChevronRight,
  Package,
  Layers,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMarketplace } from '../context/MarketplaceContext';
import { useMessaging } from '../context/MessagingContext';
import { BrandLogo } from './BrandLogo';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPublishProduct: () => void;
  onOpenFavorites: () => void;
  onOpenMessages: () => void;
  onOpenSettings: () => void;
  onOpenMyListings: () => void;
  onOpenAdminPanel?: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  onOpenPublishProduct,
  onOpenFavorites,
  onOpenMessages,
  onOpenSettings,
  onOpenMyListings,
  onOpenAdminPanel,
}) => {
  const { user, userProfile, signOutUser } = useAuth();
  const { favorites, isAdmin, products } = useMarketplace();
  const { conversations } = useMessaging();

  const handleAction = (action: () => void) => {
    onClose();
    action();
  };

  const myProductsCount = user ? products.filter(p => p.sellerId === user.uid).length : 0;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Dimmed backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-stone-950/40 backdrop-blur-xs"
          />

          {/* Side Drawer Panel */}
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 320 }}
            className="fixed inset-y-0 left-0 w-full max-w-xs sm:max-w-sm bg-white shadow-2xl flex flex-col z-10 border-r border-stone-200/80"
          >
            {/* Header: App Name and Original Brand Mark displayed right here as requested! */}
            <div className="p-5 border-b border-stone-100 bg-[#FAF9F6] relative">
              <button
                onClick={onClose}
                aria-label="إغلاق"
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white border border-stone-200 shadow-xs flex items-center justify-center text-stone-500 hover:text-stone-900 active:scale-95 transition-all"
              >
                <X className="w-4 h-4" />
              </button>

              {/* App Brand Mark & Name inside the menu */}
              <div className="flex items-center gap-3 pr-8">
                <BrandLogo size={44} />
                <div>
                  <h3 className="font-display font-black text-lg text-stone-900 leading-none">
                    AIUSHUB
                  </h3>
                  <span className="text-[11px] font-semibold text-stone-500">
                    المنصة العالمية للتجارة المباشرة
                  </span>
                </div>
              </div>

              {/* User Profile Info */}
              {user && (
                <div className="mt-4 pt-3 border-t border-stone-200/70 flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-stone-200/80 text-stone-800 font-bold flex items-center justify-center text-xs shrink-0">
                    {userProfile?.displayName?.charAt(0) || user.email?.charAt(0).toUpperCase() || 'U'}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-stone-900 truncate">
                      {userProfile?.displayName || user.displayName || user.email}
                    </div>
                    <div className="text-[10px] text-stone-500 truncate">
                      @{userProfile?.username || (user.email?.split('@')[0] || 'member')}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Navigation Items */}
            <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-1 divide-y divide-stone-100">
              {/* Primary Actions */}
              <div className="pb-2 space-y-1">
                {/* Publish Product */}
                <button
                  onClick={() => handleAction(onOpenPublishProduct)}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-stone-800 hover:bg-stone-50 active:bg-stone-100 font-bold text-xs sm:text-sm transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-900 flex items-center justify-center group-hover:bg-stone-900 group-hover:text-white transition-colors">
                      <PlusCircle className="w-4.5 h-4.5" />
                    </div>
                    <span>نشر منتج جديد</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-stone-300 group-hover:text-stone-500" />
                </button>

                {/* Liked / Favorited Products */}
                <button
                  onClick={() => handleAction(onOpenFavorites)}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-stone-800 hover:bg-stone-50 active:bg-stone-100 font-bold text-xs sm:text-sm transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                      <Heart className="w-4.5 h-4.5 fill-rose-500/20" />
                    </div>
                    <span>المنتجات المعجب بها</span>
                  </div>
                  <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
                    {favorites.length}
                  </span>
                </button>

                {/* My Products (with stock adjustment!) */}
                <button
                  onClick={() => handleAction(onOpenMyListings)}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-stone-800 hover:bg-stone-50 active:bg-stone-100 font-bold text-xs sm:text-sm transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                      <Package className="w-4.5 h-4.5" />
                    </div>
                    <span>منتجاتي (تعديل الكميات)</span>
                  </div>
                  <span className="text-xs font-bold text-stone-600 bg-stone-100 px-2 py-0.5 rounded-full">
                    {myProductsCount}
                  </span>
                </button>

                {/* Inquiries / Direct Messages */}
                <button
                  onClick={() => handleAction(onOpenMessages)}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-stone-800 hover:bg-stone-50 active:bg-stone-100 font-bold text-xs sm:text-sm transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                      <MessageSquare className="w-4.5 h-4.5" />
                    </div>
                    <span>المحادثات والاستفسارات</span>
                  </div>
                  {conversations.length > 0 && (
                    <span className="text-xs font-bold text-stone-600 bg-stone-100 px-2 py-0.5 rounded-full">
                      {conversations.length}
                    </span>
                  )}
                </button>
              </div>

              {/* Preferences */}
              <div className="pt-2 pb-2 space-y-1">
                <button
                  onClick={() => handleAction(onOpenSettings)}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-stone-800 hover:bg-stone-50 active:bg-stone-100 font-bold text-xs sm:text-sm transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                      <Settings className="w-4.5 h-4.5" />
                    </div>
                    <span>العملة والإعدادات</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-stone-300" />
                </button>

                {/* Secret Admin Panel: ONLY visible to cl4sc4@gmail.com */}
                {isAdmin && onOpenAdminPanel && (
                  <button
                    onClick={() => handleAction(onOpenAdminPanel)}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-2xl bg-amber-50 hover:bg-amber-100/80 text-amber-900 font-bold text-xs sm:text-sm transition-all border border-amber-200/80"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center">
                        <ShieldCheck className="w-4.5 h-4.5" />
                      </div>
                      <span>إدارة الأدمن (حذف المنتجات)</span>
                    </div>
                    <span className="text-[10px] uppercase font-black tracking-wider text-amber-700 bg-white px-2 py-0.5 rounded-md">
                      أدمن
                    </span>
                  </button>
                )}
              </div>
            </div>

            {/* Bottom: Sign Out */}
            <div className="p-4 border-t border-stone-100 bg-[#FAF9F6]">
              <button
                onClick={async () => {
                  await signOutUser();
                  onClose();
                }}
                className="w-full py-2.5 px-4 rounded-xl border border-stone-200 bg-white text-stone-700 hover:text-rose-600 font-bold text-xs flex items-center justify-center gap-2 active:scale-98 transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span>تسجيل الخروج</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
