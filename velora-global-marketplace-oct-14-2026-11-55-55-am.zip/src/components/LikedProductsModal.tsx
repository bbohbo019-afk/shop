import React from 'react';
import { motion } from 'motion/react';
import { X, Heart, ShoppingBag } from 'lucide-react';
import { useMarketplace } from '../context/MarketplaceContext';
import { Product } from '../types';

interface LikedProductsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
}

export const LikedProductsModal: React.FC<LikedProductsModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
}) => {
  const { products, favorites, toggleFavorite, formatPrice } = useMarketplace();

  if (!isOpen) return null;

  const likedList = products.filter(p => favorites.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-stone-950/50 backdrop-blur-xs"
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-stone-200/90 flex flex-col max-h-[88vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 bg-[#FAF9F6] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shadow-xs">
              <Heart className="w-5 h-5 fill-rose-500" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-900">
                المنتجات المعجب بها
              </h3>
              <p className="text-[11px] text-stone-500 font-medium">
                {likedList.length} منتجات في قائمتك المفضلة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-stone-200 flex items-center justify-center text-stone-500 hover:text-stone-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
          {likedList.length === 0 ? (
            <div className="text-center py-12 text-stone-400 space-y-2">
              <Heart className="w-10 h-10 mx-auto text-stone-300 stroke-[1.5]" />
              <p className="text-xs font-bold text-stone-600">لا توجد منتجات معجب بها حتى الآن</p>
              <p className="text-[11px] text-stone-400 max-w-xs mx-auto">
                اضغط على علامة الإعجاب في أي منتج لإضافته إلى قائمتك هنا.
              </p>
            </div>
          ) : (
            likedList.map((p) => {
              const isZero = p.stock !== undefined && p.stock <= 0;

              return (
                <div
                  key={p.id}
                  className="p-3 rounded-2xl border border-stone-200/80 bg-[#FAF9F6] flex items-center justify-between gap-3 hover:bg-stone-50 transition-colors"
                >
                  <div
                    onClick={() => {
                      onClose();
                      onSelectProduct(p);
                    }}
                    className="flex items-center gap-2.5 min-w-0 cursor-pointer flex-1"
                  >
                    <div className="w-12 h-12 rounded-xl bg-white border border-stone-200/70 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                      <img
                        src={p.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                        alt={p.title}
                        className={`w-full h-full object-contain mix-blend-multiply ${isZero ? 'grayscale' : ''}`}
                      />
                    </div>
                    <div className="min-w-0">
                      <h4 className={`font-bold text-xs sm:text-sm truncate ${
                        isZero ? 'line-through text-stone-400' : 'text-stone-900'
                      }`}>
                        {p.title}
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        {formatPrice(p.price, p.currency)} • {p.sellerName}
                        {isZero && <span className="mr-2 text-rose-600 font-bold">(نفذت)</span>}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleFavorite(p.id)}
                    className="w-8 h-8 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center hover:bg-rose-100 transition-colors"
                    title="إزالة من المعجب بها"
                  >
                    <Heart className="w-4 h-4 fill-current" />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </motion.div>
    </div>
  );
};
