import React from 'react';
import { motion } from 'motion/react';
import { X, Bell, Sparkles, CheckCircle2, ShoppingBag, ShieldCheck } from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const NOTIFICATIONS = [
    {
      id: 'notif-1',
      title: 'Welcome to AURA Marketplace',
      body: 'Explore unique items from verified global artisans. Add items to your inquiry cart to connect directly with sellers.',
      time: 'Just now',
      unread: true
    },
    {
      id: 'notif-2',
      title: 'Global Shipping Updates',
      body: 'Verified sellers now offer direct tracking for European and North American express dispatches.',
      time: '1h ago',
      unread: false
    },
    {
      id: 'notif-3',
      title: 'Safety Protection Active',
      body: 'Direct buyer-seller messaging includes anti-spam filtering and safety reporting.',
      time: '1d ago',
      unread: false
    }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs"
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-sm bg-white rounded-3xl shadow-xl overflow-hidden z-10 border border-slate-100 p-5 space-y-4"
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-4.5 h-4.5 text-indigo-600" />
            <h3 className="font-bold text-sm text-slate-900">Notifications</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {NOTIFICATIONS.map((n) => (
            <div
              key={n.id}
              className={`p-3 rounded-2xl border transition-all ${
                n.unread
                  ? 'bg-indigo-50/50 border-indigo-100/80'
                  : 'bg-[#FBFBFC] border-slate-100'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <h4 className="font-bold text-xs text-slate-900">{n.title}</h4>
                <span className="text-[10px] text-slate-400">{n.time}</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">{n.body}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};
