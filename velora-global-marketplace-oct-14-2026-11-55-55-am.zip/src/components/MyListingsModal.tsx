import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Package, Edit3, Check, Trash2, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMarketplace } from '../context/MarketplaceContext';
import { Product } from '../types';

interface MyListingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
}

export const MyListingsModal: React.FC<MyListingsModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
}) => {
  const { user } = useAuth();
  const { products, updateProductStock, deleteProduct, formatPrice } = useMarketplace();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [stockVal, setStockVal] = useState<number>(0);
  const [loadingId, setLoadingId] = useState<string | null>(null);

  if (!isOpen) return null;

  const myProducts = user ? products.filter(p => p.sellerId === user.uid) : [];

  const handleStartEdit = (product: Product) => {
    setEditingId(product.id);
    setStockVal(product.stock !== undefined ? product.stock : 1);
  };

  const handleSaveStock = async (productId: string) => {
    setLoadingId(productId);
    try {
      await updateProductStock(productId, stockVal);
      setEditingId(null);
    } catch (err) {
      console.error(err);
      alert('تعذر تحديث الكمية.');
    } finally {
      setLoadingId(null);
    }
  };

  const handleDelete = async (productId: string, title: string) => {
    if (confirm(`هل أنت متأكد من حذف المنتج: "${title}"؟`)) {
      await deleteProduct(productId);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-stone-950/50 backdrop-blur-xs"
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-stone-200/90 flex flex-col max-h-[88vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 bg-[#FAF9F6] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-stone-900 text-white flex items-center justify-center shadow-xs">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-900">
                منتجاتي المعروضة
              </h3>
              <p className="text-[11px] text-stone-500 font-medium">
                يمكنك فقط تعديل عدد القطع المتبقية لكل منتج
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-stone-200 flex items-center justify-center text-stone-500 hover:text-stone-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {myProducts.length === 0 ? (
            <div className="text-center py-12 text-stone-400 space-y-2">
              <Package className="w-10 h-10 mx-auto text-stone-300 stroke-[1.5]" />
              <p className="text-xs font-bold text-stone-600">لم تقم بنشر أي منتجات حتى الآن</p>
              <p className="text-[11px] text-stone-400 max-w-xs mx-auto">
                اضغط على زر نشر منتج لعرض سلعك في السوق لجميع الزوار.
              </p>
            </div>
          ) : (
            myProducts.map((p) => {
              const isZero = p.stock !== undefined && p.stock <= 0;
              const isEditing = editingId === p.id;

              return (
                <div
                  key={p.id}
                  className="p-3.5 rounded-2xl border border-stone-200/90 bg-[#FAF9F6] space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div 
                      onClick={() => {
                        onClose();
                        onSelectProduct(p);
                      }}
                      className="flex items-center gap-2.5 min-w-0 cursor-pointer flex-1"
                    >
                      <div className="w-12 h-12 rounded-xl bg-white border border-stone-200/80 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                        <img
                          src={p.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                          alt={p.title}
                          className={`w-full h-full object-contain mix-blend-multiply ${isZero ? 'grayscale' : ''}`}
                        />
                      </div>
                      <div className="min-w-0">
                        <h4 className={`font-bold text-xs sm:text-sm truncate ${
                          isZero ? 'line-through text-stone-400' : 'text-stone-900'
                        }`}>
                          {p.title}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          السعر: {formatPrice(p.price, p.currency)}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDelete(p.id, p.title)}
                      className="text-stone-400 hover:text-rose-600 p-1 transition-colors"
                      title="حذف المنتج"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Stock Editing Section */}
                  <div className="pt-2 border-t border-stone-200/60 flex items-center justify-between">
                    <div className="text-xs text-stone-600">
                      القطع المتبقية: <strong className="text-stone-900 font-bold">{p.stock !== undefined ? p.stock : 1}</strong>
                      {isZero && (
                        <span className="mr-2 text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
                          نفذت الكمية
                        </span>
                      )}
                    </div>

                    {isEditing ? (
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={stockVal}
                          onChange={(e) => setStockVal(parseInt(e.target.value) || 0)}
                          className="w-16 px-2 py-1 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-900 text-center"
                        />
                        <button
                          onClick={() => handleSaveStock(p.id)}
                          disabled={loadingId === p.id}
                          className="px-2.5 py-1 rounded-lg bg-stone-900 text-white text-xs font-bold"
                        >
                          {loadingId === p.id ? '...' : 'حفظ'}
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="px-2 py-1 rounded-lg border border-stone-200 text-stone-600 text-xs"
                        >
                          إلغاء
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleStartEdit(p)}
                        className="px-3 py-1 rounded-xl bg-white border border-stone-200 text-stone-800 text-xs font-bold shadow-xs hover:bg-stone-50 flex items-center gap-1.5"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>تعديل الكمية</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </motion.div>
    </div>
  );
};
