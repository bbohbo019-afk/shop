import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Upload, 
  Trash2, 
  AlertCircle, 
  CheckCircle2, 
  Image as ImageIcon,
  DollarSign,
  Package,
  ExternalLink,
  Plus,
  Sparkles,
  MessageCircle,
  Send,
  Globe
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMarketplace } from '../context/MarketplaceContext';

interface PublishProductModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Client-side image compressor ensuring multiple images comfortably stay under Firestore's 1MB limit
const compressImageFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 600; // Optimal resolution for mobile commerce cards
        let width = img.width;
        let height = img.height;

        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.65));
        } else {
          resolve(e.target?.result as string);
        }
      };
      img.onerror = () => reject(new Error('فشل قراءة الصورة'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('فشل تحميل الملف'));
    reader.readAsDataURL(file);
  });
};

// Preset high quality product images for quick selection
const QUICK_IMAGE_PRESETS = [
  { label: 'سماعات فاخرة', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80' },
  { label: 'ساعة يد كلاسيكية', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80' },
  { label: 'عطر راقي', url: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=800&auto=format&fit=crop&q=80' },
  { label: 'حقيبة جلدية', url: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&auto=format&fit=crop&q=80' },
  { label: 'كاميرا احترافية', url: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&auto=format&fit=crop&q=80' },
];

export const PublishProductModal: React.FC<PublishProductModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { user } = useAuth();
  const { createProductListing } = useMarketplace();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [stock, setStock] = useState('1');
  const [whatsapp, setWhatsapp] = useState('');
  const [telegram, setTelegram] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  
  // Up to 10 images
  const [images, setImages] = useState<string[]>([]);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [compressing, setCompressing] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  // Handle local file uploads (multiple allowed, up to 10)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const remainingSlots = 10 - images.length;
    if (remainingSlots <= 0) {
      setError('الحد الأقصى للصور هو 10 صور فقط.');
      return;
    }

    setCompressing(true);
    setError(null);

    const filesToLoad = Array.from(files).slice(0, remainingSlots);

    try {
      for (const file of filesToLoad) {
        if (!file.type.startsWith('image/')) continue;
        const compressed = await compressImageFile(file);
        setImages((prev) => (prev.length < 10 ? [...prev, compressed] : prev));
      }
    } catch (err: any) {
      console.warn("Image load warning:", err);
      setError('تعذر قراءة بعض الصور، يرجى المحاولة بصيغة أخرى.');
    } finally {
      setCompressing(false);
      // Reset input value to allow selecting same file again
      e.target.value = '';
    }
  };

  const handleAddImageUrl = () => {
    if (!imageUrlInput.trim()) return;
    if (images.length >= 10) {
      setError('الحد الأقصى للصور هو 10 صور.');
      return;
    }
    setImages((prev) => [...prev, imageUrlInput.trim()]);
    setImageUrlInput('');
  };

  const handleSelectPreset = (url: string) => {
    if (images.length >= 10) {
      setError('الحد الأقصى للصور هو 10 صور.');
      return;
    }
    setImages((prev) => [...prev, url]);
  };

  const handleRemoveImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!user) {
      setError('يجب تسجيل الدخول لنشر منتج.');
      return;
    }

    if (!title.trim()) {
      setError('يرجى إدخال اسم المنتج.');
      return;
    }

    const numPrice = parseFloat(price);
    if (isNaN(numPrice) || numPrice < 0) {
      setError('يرجى تحديد سعر صالح للمنتج.');
      return;
    }

    const numStock = parseInt(stock);
    if (isNaN(numStock) || numStock < 0) {
      setError('يرجى تحديد عدد القطع المتبقية (0 أو أكثر).');
      return;
    }

    // Default sample image if user didn't upload any
    const finalImages = images.length > 0 ? images : [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'
    ];

    setLoading(true);

    try {
      await createProductListing({
        title: title.trim(),
        description: description.trim() || 'منتج متاح للطلب والتواصل المباشر.',
        price: numPrice,
        currency,
        category: 'عام',
        condition: 'جديد',
        images: finalImages,
        stock: numStock,
        whatsapp: whatsapp.trim() || undefined,
        telegram: telegram.trim().replace('@', '') || undefined,
        websiteUrl: websiteUrl.trim() || undefined,
        contactPreference: whatsapp ? 'WhatsApp' : telegram ? 'Telegram' : 'Direct Contact'
      });

      setSuccess(true);
      // Reset form fields
      setTitle('');
      setDescription('');
      setPrice('');
      setStock('1');
      setWhatsapp('');
      setTelegram('');
      setWebsiteUrl('');
      setImages([]);

      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1200);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'فشل نشر المنتج، يرجى مراجعة البيانات والمحاولة ثانية.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs"
      />

      {/* Modal Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-stone-200/90 my-6 flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 bg-[#FAF9F6] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-stone-900 text-white flex items-center justify-center shadow-xs">
              <Package className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="font-display font-bold text-base sm:text-lg text-stone-900">
                نشر منتج جديد
              </h2>
              <p className="text-[11px] text-stone-500 font-medium">
                سيظهر لجميع الزوار مباشرة مع قنوات التواصل
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-stone-200 shadow-xs flex items-center justify-center text-stone-500 hover:text-stone-900 active:scale-95 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span className="font-bold">تم نشر المنتج بنجاح في السوق!</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Product Name */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                اسم المنتج *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="اكتب اسم المنتج بدقة ووضوح..."
                className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900 transition-all"
              />
            </div>

            {/* Images Upload & Management (Max 10 images) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-stone-600" />
                  <span>صور المنتج (الحد الأقصى 10 صور)</span>
                </label>
                <span className="text-[11px] font-bold text-stone-500 bg-stone-100 px-2 py-0.5 rounded-full">
                  {images.length} / 10
                </span>
              </div>

              {/* Upload actions */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <label className="cursor-pointer flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-800 text-xs font-bold active:scale-98 transition-all shrink-0">
                  <Upload className="w-3.5 h-3.5 text-stone-600" />
                  <span>{compressing ? 'جار معالجة الصور...' : 'رفع صور من الجهاز'}</span>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    disabled={compressing || images.length >= 10}
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                <div className="flex-1 flex gap-1.5">
                  <input
                    type="url"
                    value={imageUrlInput}
                    onChange={(e) => setImageUrlInput(e.target.value)}
                    placeholder="أو ضع رابط صورة مباشرة"
                    className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                  <button
                    type="button"
                    onClick={handleAddImageUrl}
                    disabled={!imageUrlInput.trim() || images.length >= 10}
                    className="px-3 py-2 rounded-xl bg-stone-900 text-white text-xs font-bold disabled:opacity-50"
                  >
                    إضافة
                  </button>
                </div>
              </div>

              {/* Quick image presets */}
              <div className="pt-1">
                <span className="block text-[10px] font-semibold text-stone-400 mb-1">
                  أو اختر صورة جاهزة سريعة:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {QUICK_IMAGE_PRESETS.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectPreset(p.url)}
                      disabled={images.length >= 10}
                      className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 text-[10px] font-medium transition-colors"
                    >
                      + {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Thumbnails preview */}
              {images.length > 0 && (
                <div className="grid grid-cols-5 gap-2 pt-2">
                  {images.map((img, i) => (
                    <div key={i} className="relative aspect-square rounded-xl border border-stone-200 overflow-hidden group shadow-xs">
                      <img src={img} alt={`preview ${i}`} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(i)}
                        title="حذف الصورة"
                        className="absolute inset-0 bg-stone-950/70 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                      >
                        <Trash2 className="w-4 h-4 text-rose-300" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Price & Currency & Remaining Stock */}
            <div className="grid grid-cols-3 gap-2.5">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  السعر *
                </label>
                <div className="flex gap-1.5">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="0.00"
                    className="flex-1 px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                  />
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-28 px-2 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold text-stone-900 focus:bg-white focus:outline-none"
                  >
                    <option value="IQD">IQD (د.ع)</option>
                    <option value="SAR">SAR (ر.س)</option>
                    <option value="AED">AED (د.إ)</option>
                    <option value="KWD">KWD (د.ك)</option>
                    <option value="QAR">QAR (ر.ق)</option>
                    <option value="EGP">EGP (ج.م)</option>
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="TRY">TRY (₺)</option>
                    <option value="JPY">JPY (¥)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  القطع المتوفرة *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                  placeholder="1"
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>
            </div>

            {/* Product Description */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                وصف ومواصفات المنتج *
              </label>
              <textarea
                rows={3}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اكتب مواصفات وتفاصيل المنتج وحالته..."
                className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 focus:bg-white focus:outline-none focus:border-stone-900 transition-all resize-none"
              />
            </div>

            {/* Direct Contact Channels */}
            <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2.5">
              <label className="block text-xs font-bold text-stone-900">
                طرق تواصل الزبائن معك:
              </label>

              {/* WhatsApp */}
              <div>
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-stone-600 mb-1">
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span>رقم الواتساب (اختياري، بالصيغة الدولية):</span>
                </span>
                <input
                  type="tel"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  placeholder="+964xxxxxxxxx أو +966xxxxxxxxx"
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-stone-900"
                />
              </div>

              {/* Telegram */}
              <div>
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-stone-600 mb-1">
                  <Send className="w-3.5 h-3.5 text-sky-600" />
                  <span>معرف أو رابط تليجرام (اختياري):</span>
                </span>
                <input
                  type="text"
                  value={telegram}
                  onChange={(e) => setTelegram(e.target.value)}
                  placeholder="username أو t.me/..."
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-stone-900"
                />
              </div>

              {/* External Website */}
              <div>
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-stone-600 mb-1">
                  <Globe className="w-3.5 h-3.5 text-stone-600" />
                  <span>رابط موقع خارجي أو متجر (اختياري):</span>
                </span>
                <input
                  type="url"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:border-stone-900"
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={loading || compressing}
                className="w-full py-3.5 px-4 rounded-2xl bg-stone-900 text-white font-bold text-xs sm:text-sm hover:bg-stone-800 shadow-md shadow-stone-900/10 active:scale-98 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <span>نشر المنتج في السوق</span>
                )}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};
