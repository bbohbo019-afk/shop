import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  MessageSquare, 
  ShoppingBag, 
  Info, 
  ArrowRight,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { useMarketplace } from '../context/MarketplaceContext';
import { useMessaging } from '../context/MessagingContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenMessages: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  onOpenMessages,
}) => {
  const { 
    cart, 
    removeFromCart, 
    updateCartQuantity, 
    clearCart, 
    cartCount, 
    cartSubtotal, 
    formatPrice,
    activeCurrency 
  } = useMarketplace();

  const { startConversation } = useMessaging();
  const [inquireStatus, setInquireStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleInquireAll = async () => {
    if (cart.length === 0) return;
    
    // Group unique sellers from cart items
    const sellers = new Map<string, { id: string; name: string }>();
    cart.forEach(item => {
      sellers.set(item.product.sellerId, {
        id: item.product.sellerId,
        name: item.product.sellerName
      });
    });

    // Start conversation with the first seller in the cart
    const firstSeller = Array.from(sellers.values())[0];
    if (firstSeller) {
      const firstProduct = cart[0].product;
      await startConversation(firstSeller.id, firstSeller.name, firstProduct);
      setInquireStatus(`Initiated direct inquiry with ${firstSeller.name}!`);
      setTimeout(() => {
        setInquireStatus(null);
        onClose();
        onOpenMessages();
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs"
      />

      {/* Cart Container */}
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="relative w-full max-w-md bg-white shadow-2xl flex flex-col z-10 h-full border-l border-slate-100"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-[#FAF9FC]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center shadow-sm">
              <ShoppingBag className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className="font-display font-bold text-base text-slate-900">
                Inquiry & Order Cart
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">
                {cartCount} {cartCount === 1 ? 'item saved' : 'items saved'} for inquiry
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-[11px] font-semibold text-rose-500 hover:text-rose-700 px-2 py-1"
              >
                Clear
              </button>
            )}
            <button
              onClick={onClose}
              aria-label="Close cart"
              className="w-8 h-8 rounded-full bg-white border border-slate-200 shadow-xs flex items-center justify-center text-slate-500 hover:text-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Informational Disclaimer Banner */}
        <div className="p-3 bg-indigo-50/70 border-b border-indigo-100/60 flex items-start gap-2.5 text-indigo-900 text-xs">
          <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong className="font-bold">Direct Seller Inquiry:</strong> AURA does not process product payments. Items in this cart organize your inquiries to arrange direct delivery with verified sellers.
          </p>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-3">
              <div className="w-16 h-16 rounded-3xl bg-slate-100 flex items-center justify-center text-slate-400">
                <ShoppingBag className="w-8 h-8 stroke-[1.5]" />
              </div>
              <h3 className="font-bold text-slate-700 text-base">Your Inquiry Cart is Empty</h3>
              <p className="text-xs text-slate-400 max-w-xs">
                Explore unique handcrafted goods, timepieces, audio and fashion to save items for direct seller inquiries.
              </p>
            </div>
          ) : (
            cart.map((item, index) => (
              <div
                key={`${item.product.id}-${item.selectedColor}-${item.selectedSize}-${index}`}
                className="p-3 rounded-2xl bg-[#FBFBFC] border border-slate-200/80 shadow-xs flex gap-3 items-center"
              >
                {/* Product Thumbnail */}
                <div 
                  className="w-18 h-18 rounded-xl flex items-center justify-center p-1.5 shrink-0 overflow-hidden"
                  style={{ backgroundColor: item.product.backgroundTint || '#ECE9F2' }}
                >
                  <img
                    src={item.product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300'}
                    alt={item.product.title}
                    className="w-full h-full object-contain mix-blend-multiply"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                    {item.product.title}
                  </h4>
                  <div className="text-[11px] text-slate-400 mt-0.5 space-x-2">
                    {item.selectedColor && (
                      <span>Tone: <strong className="text-slate-700 font-semibold">{item.selectedColor}</strong></span>
                    )}
                    {item.selectedSize && (
                      <span>Size: <strong className="text-slate-700 font-semibold">{item.selectedSize}</strong></span>
                    )}
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 mt-1">
                    {formatPrice(item.product.price * item.quantity, item.product.currency)}
                  </div>
                </div>

                {/* Quantity Controls & Remove */}
                <div className="flex flex-col items-end gap-2 shrink-0">
                  <button
                    onClick={() => removeFromCart(item.product.id, item.selectedColor)}
                    className="text-slate-400 hover:text-rose-500 p-1 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg p-0.5">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1, item.selectedColor)}
                      className="w-5 h-5 flex items-center justify-center text-slate-600 hover:bg-slate-100 rounded"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-4 text-center text-xs font-bold text-slate-800">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1, item.selectedColor)}
                      className="w-5 h-5 flex items-center justify-center text-slate-600 hover:bg-slate-100 rounded"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Subtotal & Action */}
        {cart.length > 0 && (
          <div className="p-5 border-t border-slate-100 bg-[#FAF9FC] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                Reference Subtotal ({activeCurrency})
              </span>
              <span className="font-display font-black text-xl text-slate-900">
                {formatPrice(cartSubtotal, 'USD')}
              </span>
            </div>

            {inquireStatus ? (
              <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold text-center">
                {inquireStatus}
              </div>
            ) : (
              <button
                onClick={handleInquireAll}
                className="w-full py-3.5 px-4 rounded-2xl bg-slate-950 text-white font-bold text-xs sm:text-sm hover:bg-slate-800 shadow-lg shadow-slate-950/15 active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4 text-indigo-400" />
                <span>Inquire About Items with Seller</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            <p className="text-[10px] text-center text-slate-400">
              Direct peer-to-peer inquiry. Agree on payment & shipping with the seller.
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
};
