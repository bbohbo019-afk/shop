import React from 'react';
import { Heart, MessageSquare, Tag, PlusCircle, Share2, Sparkles, CheckCircle2 } from 'lucide-react';
import { useMarketplace } from '../context/MarketplaceContext';
import { Post, Product } from '../types';
import confetti from 'canvas-confetti';

interface SocialFeedSectionProps {
  onSelectProduct: (product: Product) => void;
  onOpenPublishPost: () => void;
}

export const SocialFeedSection: React.FC<SocialFeedSectionProps> = ({
  onSelectProduct,
  onOpenPublishPost,
}) => {
  const { posts, products, likePost } = useMarketplace();

  const handleLike = (e: React.MouseEvent, postId: string) => {
    e.stopPropagation();
    likePost(postId);
    try {
      confetti({
        particleCount: 20,
        spread: 40,
        origin: { y: 0.7 },
        colors: ['#F43F5E', '#EC4899', '#818CF8']
      });
    } catch {}
  };

  return (
    <div className="space-y-4">
      {/* Feed Section Title & Post CTA */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-extrabold text-xl sm:text-2xl text-slate-900 tracking-tight">
            Community & Maker Stories
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            Behind the scenes, craft announcements, and design highlights
          </p>
        </div>

        <button
          onClick={onOpenPublishPost}
          className="px-3.5 py-2 rounded-2xl bg-white border border-slate-200/90 hover:bg-slate-50 text-slate-900 text-xs font-bold shadow-xs active:scale-95 transition-all flex items-center gap-1.5"
        >
          <PlusCircle className="w-4 h-4 text-indigo-600" />
          <span>Post Story</span>
        </button>
      </div>

      {/* Posts Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {posts.map((post) => {
          const associatedProduct = post.taggedProductId
            ? products.find((p) => p.id === post.taggedProductId)
            : undefined;

          return (
            <div
              key={post.id}
              className="bg-white rounded-3xl p-5 border border-slate-200/70 shadow-[0_4px_20px_rgb(0,0,0,0.02)] hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Author Info */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    {post.authorAvatar ? (
                      <img
                        src={post.authorAvatar}
                        alt={post.authorName}
                        className="w-9 h-9 rounded-full object-cover ring-2 ring-indigo-500/10"
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-full bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center">
                        {post.authorName.charAt(0)}
                      </div>
                    )}
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 leading-tight">
                        {post.authorName}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {new Date(post.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                      </p>
                    </div>
                  </div>

                  {post.isSample && (
                    <span className="text-[9px] font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                      Sample Post
                    </span>
                  )}
                </div>

                {/* Content text */}
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {post.content}
                </p>

                {/* Optional Image */}
                {post.imageURL && (
                  <div className="mt-3 rounded-2xl overflow-hidden aspect-video bg-slate-100 border border-slate-100">
                    <img
                      src={post.imageURL}
                      alt="post media"
                      loading="lazy"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {/* Associated Tagged Product Pill */}
                {associatedProduct && (
                  <div
                    onClick={() => onSelectProduct(associatedProduct)}
                    className="mt-3 p-2.5 rounded-2xl bg-[#F6F5F9] hover:bg-[#EFEBF7] border border-slate-200/60 cursor-pointer flex items-center justify-between gap-3 group transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center p-1 shrink-0 overflow-hidden">
                        <img
                          src={associatedProduct.images?.[0]}
                          alt={associatedProduct.title}
                          className="w-full h-full object-contain mix-blend-multiply"
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-indigo-600">
                          <Tag className="w-3 h-3" />
                          <span>Tagged Product</span>
                        </div>
                        <h5 className="font-bold text-xs text-slate-900 truncate group-hover:text-indigo-600 transition-colors">
                          {associatedProduct.title}
                        </h5>
                      </div>
                    </div>
                    <span className="text-xs font-black text-slate-900 shrink-0">
                      ${associatedProduct.price}
                    </span>
                  </div>
                )}
              </div>

              {/* Interaction Bar (Like, Comments, Share) */}
              <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <button
                  onClick={(e) => handleLike(e, post.id)}
                  className="flex items-center gap-1.5 hover:text-rose-500 active:scale-95 transition-all"
                >
                  <Heart className="w-4 h-4 text-rose-500 fill-rose-50" />
                  <span className="font-semibold">{post.likesCount}</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-slate-400" />
                  <span className="font-semibold">{post.commentsCount} comments</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
