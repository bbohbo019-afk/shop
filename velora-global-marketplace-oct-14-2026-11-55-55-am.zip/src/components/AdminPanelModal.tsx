import React from 'react';
import { motion } from 'motion/react';
import { X, Trash2, ShieldCheck, AlertCircle, Package } from 'lucide-react';
import { useMarketplace } from '../context/MarketplaceContext';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({ isOpen, onClose }) => {
  const { products, deleteProduct, formatPrice, isAdmin } = useMarketplace();

  if (!isOpen || !isAdmin) return null;

  const handleDelete = async (productId: string, title: string) => {
    if (confirm(`تأكيد حذف المنتج بصلاحيات الأدمن:\n"${title}"؟`)) {
      await deleteProduct(productId);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-stone-950/50 backdrop-blur-xs"
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-stone-200/90 flex flex-col max-h-[88vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 bg-amber-50/60 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-stone-900">
                لوحة تحكم الأدمن (إدارة وحذف المنتجات)
              </h3>
              <p className="text-[11px] text-amber-900/80 font-medium">
                خاصة بحسابك cl4sc4@gmail.com فقط
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-stone-200 flex items-center justify-center text-stone-500 hover:text-stone-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Product List for Admin Deletion */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1">
          <p className="text-xs text-stone-500 pb-1">
            إجمالي المنتجات المعروضة في المنصة: <strong className="text-stone-900">{products.length}</strong> منتج
          </p>

          {products.length === 0 ? (
            <div className="text-center py-12 text-stone-400 text-xs">
              لا توجد منتجات حالياً.
            </div>
          ) : (
            products.map((p) => (
              <div
                key={p.id}
                className="p-3 rounded-2xl border border-stone-200/80 bg-stone-50/50 flex items-center justify-between gap-3 hover:bg-stone-50 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-xl bg-white border border-stone-200/70 overflow-hidden flex items-center justify-center shrink-0 p-1">
                    <img
                      src={p.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                      alt={p.title}
                      className="w-full h-full object-contain mix-blend-multiply"
                    />
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-bold text-xs sm:text-sm text-stone-900 truncate">
                      {p.title}
                    </h4>
                    <p className="text-[11px] text-stone-500">
                      البائع: <span className="font-semibold text-stone-700">{p.sellerName}</span> • السعر: {formatPrice(p.price, p.currency)} • المتبقي: {p.stock ?? 1}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleDelete(p.id, p.title)}
                  className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 text-xs font-bold flex items-center gap-1.5 shrink-0 active:scale-95 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>حذف</span>
                </button>
              </div>
            ))
          )}
        </div>

        <div className="p-3.5 border-t border-stone-100 bg-[#FAF9F6] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-stone-900 text-white font-bold text-xs"
          >
            إغلاق اللوحة
          </button>
        </div>
      </motion.div>
    </div>
  );
};
