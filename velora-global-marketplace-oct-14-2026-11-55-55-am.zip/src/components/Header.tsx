import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MoreHorizontal, Search, ShoppingBag, X } from 'lucide-react';
import { useMarketplace } from '../context/MarketplaceContext';

interface HeaderProps {
  onOpenMenu: () => void;
  onOpenCart: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenMenu, onOpenCart }) => {
  const { cartCount, searchQuery, setSearchQuery } = useMarketplace();
  const [isSearchVisible, setIsSearchVisible] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#F8F7F4]/95 backdrop-blur-md px-4 py-2.5 border-b border-stone-200/70 transition-all duration-200">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-3">
        {/* Left: The requested "..." menu button */}
        <button
          onClick={onOpenMenu}
          aria-label="القائمة"
          className="w-10 h-10 rounded-2xl bg-white border border-stone-200/90 shadow-xs flex items-center justify-center text-stone-700 hover:text-stone-950 hover:bg-stone-50 active:scale-95 transition-all"
        >
          <MoreHorizontal className="w-5 h-5 stroke-[2.2]" />
        </button>

        {/* Right side: Small search button with magnifying glass + Cart button */}
        <div className="flex items-center gap-2">
          {/* Small search trigger button */}
          <button
            onClick={() => setIsSearchVisible(!isSearchVisible)}
            aria-label="البحث"
            className={`w-10 h-10 rounded-2xl border shadow-xs flex items-center justify-center active:scale-95 transition-all ${
              isSearchVisible || searchQuery
                ? 'bg-stone-900 border-stone-900 text-white'
                : 'bg-white border-stone-200/90 text-stone-700 hover:text-stone-950 hover:bg-stone-50'
            }`}
          >
            <Search className="w-4.5 h-4.5 stroke-[2]" />
          </button>

          {/* Cart button */}
          <button
            onClick={onOpenCart}
            aria-label="السلة"
            className="relative w-10 h-10 rounded-2xl bg-white border border-stone-200/90 shadow-xs flex items-center justify-center text-stone-800 hover:bg-stone-50 active:scale-95 transition-all"
          >
            <ShoppingBag className="w-4.5 h-4.5 stroke-[2]" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[19px] h-[19px] px-1 rounded-full bg-stone-900 text-white text-[10px] font-extrabold flex items-center justify-center border-2 border-[#F8F7F4]">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Expandable smooth search bar */}
      <AnimatePresence>
        {isSearchVisible && (
          <motion.div
            initial={{ opacity: 0, height: 0, y: -4 }}
            animate={{ opacity: 1, height: 'auto', y: 0 }}
            exit={{ opacity: 0, height: 0, y: -4 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden pt-2.5 max-w-5xl mx-auto"
          >
            <div className="relative flex items-center">
              <Search className="absolute left-3.5 w-4 h-4 text-stone-400 pointer-events-none" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن منتج..."
                className="w-full h-10 pl-9.5 pr-8 bg-white border border-stone-300/80 rounded-2xl text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 shadow-xs focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 p-1 text-stone-400 hover:text-stone-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
