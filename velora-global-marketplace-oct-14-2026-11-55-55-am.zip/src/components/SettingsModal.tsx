import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Settings, 
  Globe, 
  Check, 
  ShieldCheck, 
  Languages,
  ChevronDown,
  Search,
  Coins
} from 'lucide-react';
import { useMarketplace } from '../context/MarketplaceContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { activeCurrency, setActiveCurrency, currenciesList } = useMarketplace();
  // Language toggle exclusively inside settings as requested ("سوي بالاعدادات نسخة انجليزية تكون فقط بالاعدادات")
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [isCurrencyPickerOpen, setIsCurrencyPickerOpen] = useState(false);
  const [currencySearch, setCurrencySearch] = useState('');

  const isEn = language === 'en';

  const currentCurrencyObj = useMemo(() => {
    return currenciesList.find(c => c.code === activeCurrency) || currenciesList[0];
  }, [currenciesList, activeCurrency]);

  const filteredCurrencies = useMemo(() => {
    if (!currencySearch.trim()) return currenciesList;
    const q = currencySearch.toLowerCase();
    return currenciesList.filter(c => 
      c.code.toLowerCase().includes(q) ||
      c.nameAr.toLowerCase().includes(q) ||
      c.nameEn.toLowerCase().includes(q) ||
      c.symbol.toLowerCase().includes(q)
    );
  }, [currenciesList, currencySearch]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-stone-950/50 backdrop-blur-xs"
      />

      {/* Main Settings Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-stone-200/90 my-6 flex flex-col"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 bg-[#FAF9F6] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-stone-900 text-white flex items-center justify-center shadow-xs">
              <Settings className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-sm sm:text-base text-stone-900">
                {isEn ? 'Preferences & Settings' : 'الإعدادات والتفضيلات'}
              </h3>
              <p className="text-[11px] text-stone-500 font-medium">
                {isEn ? 'Currency conversion & interface options' : 'تحديد العملة والخيارات الإقليمية'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="إغلاق"
            className="w-8 h-8 rounded-full bg-white border border-stone-200 flex items-center justify-center text-stone-500 hover:text-stone-900 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-5">
          {/* Language Selector (English / Arabic toggle inside settings) */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
              <Languages className="w-4 h-4 text-stone-600" />
              <span>{isEn ? 'Settings Language' : 'لغة الإعدادات'}</span>
            </label>
            <p className="text-[11px] text-stone-500">
              {isEn ? 'Toggle settings description to English or Arabic:' : 'اختر لغة عرض خيارات الإعدادات:'}
            </p>
            <div className="grid grid-cols-2 gap-2 pt-0.5">
              <button
                type="button"
                onClick={() => setLanguage('ar')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  language === 'ar'
                    ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                    : 'bg-stone-50 hover:bg-white border-stone-200 text-stone-700'
                }`}
              >
                <span>العربية</span>
                {language === 'ar' && <Check className="w-3.5 h-3.5" />}
              </button>

              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  language === 'en'
                    ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                    : 'bg-stone-50 hover:bg-white border-stone-200 text-stone-700'
                }`}
              >
                <span>English</span>
                {language === 'en' && <Check className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Currency selection trigger (opens "اختر عملتك" picker) */}
          <div className="space-y-2 pt-2 border-t border-stone-100">
            <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
              <Coins className="w-4 h-4 text-stone-600" />
              <span>{isEn ? 'Display Currency' : 'العملة المعروضة'}</span>
            </label>
            <p className="text-[11px] text-stone-500">
              {isEn 
                ? 'Choose your regional currency to convert product prices instantly:' 
                : 'اضغط لاختيار العملة المناسبة لتحويل أسعار المنتجات في التطبيق:'}
            </p>
            
            {/* Interactive Currency Card Trigger */}
            <button
              type="button"
              onClick={() => {
                setCurrencySearch('');
                setIsCurrencyPickerOpen(true);
              }}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-stone-50 hover:bg-stone-100/90 border border-stone-200 transition-all text-right group active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl drop-shadow-xs">{currentCurrencyObj?.flag || '🌐'}</span>
                <div>
                  <div className="font-bold text-stone-900 text-xs sm:text-sm flex items-center gap-1.5">
                    <span>{isEn ? currentCurrencyObj?.nameEn : currentCurrencyObj?.nameAr}</span>
                    <span className="text-stone-400 font-bold text-xs">({currentCurrencyObj?.code})</span>
                  </div>
                  <div className="text-[11px] text-stone-500 font-medium">
                    {isEn ? 'Symbol: ' : 'الرمز: '}
                    <span className="font-bold text-stone-800">{currentCurrencyObj?.symbol}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1 text-xs font-bold text-stone-700 bg-white px-3 py-1.5 rounded-xl border border-stone-200 shadow-xs group-hover:border-stone-400 group-hover:bg-stone-50 transition-all">
                <span>{isEn ? 'Change' : 'اختر عملتك'}</span>
                <ChevronDown className="w-3.5 h-3.5 text-stone-400 group-hover:text-stone-700" />
              </div>
            </button>
          </div>

          {/* Platform Security Standard */}
          <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/80 flex items-start gap-2.5 text-stone-600 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-stone-800 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              {isEn 
                ? 'Peer-to-peer commerce without transaction fees. Direct connection via WhatsApp, Telegram, or verified external links.' 
                : 'تجارة مباشرة بين البائع والمشتري بدون عمولات. تواصل مباشر عبر واتساب، تليجرام، أو الروابط المعتمدة.'}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-100 bg-[#FAF9F6] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold text-xs hover:bg-stone-800 transition-all"
          >
            {isEn ? 'Close' : 'إغلاق'}
          </button>
        </div>
      </motion.div>

      {/* CURRENCY PICKER POPUP: "اختر عملتك" */}
      <AnimatePresence>
        {isCurrencyPickerOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCurrencyPickerOpen(false)}
              className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden z-20 border border-stone-200 flex flex-col max-h-[85vh]"
            >
              {/* Header */}
              <div className="p-4 border-b border-stone-100 bg-[#FAF9F6] flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-stone-900 text-white flex items-center justify-center">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-sm text-stone-900">
                      {isEn ? 'Choose Your Currency' : 'اختر عملتك'}
                    </h4>
                    <p className="text-[10px] text-stone-500">
                      {isEn ? 'Select a currency to convert all prices' : 'حدد العملة لتحديث كافة الأسعار تلقائياً'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsCurrencyPickerOpen(false)}
                  className="w-7 h-7 rounded-full bg-white border border-stone-200 flex items-center justify-center text-stone-500 hover:text-stone-900"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Search Box */}
              <div className="p-3 border-b border-stone-100 bg-stone-50/60 shrink-0">
                <div className="relative">
                  <Search className="w-4 h-4 text-stone-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={currencySearch}
                    onChange={(e) => setCurrencySearch(e.target.value)}
                    placeholder={isEn ? 'Search currency...' : 'ابحث عن العملة أو الرمز...'}
                    className="w-full pl-3 pr-9 py-2 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:border-stone-900"
                  />
                  {currencySearch && (
                    <button
                      type="button"
                      onClick={() => setCurrencySearch('')}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Currency List */}
              <div className="overflow-y-auto p-2.5 divide-y divide-stone-100">
                {filteredCurrencies.map((curr) => {
                  const isSelected = activeCurrency === curr.code;
                  return (
                    <button
                      key={curr.code}
                      type="button"
                      onClick={() => {
                        setActiveCurrency(curr.code);
                        setIsCurrencyPickerOpen(false);
                      }}
                      className={`w-full flex items-center justify-between p-3 rounded-2xl transition-all text-right active:scale-[0.99] ${
                        isSelected 
                          ? 'bg-stone-900 text-white shadow-xs' 
                          : 'hover:bg-stone-50 text-stone-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{curr.flag}</span>
                        <div>
                          <div className={`text-xs font-bold flex items-center gap-1.5 ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                            <span>{isEn ? curr.nameEn : curr.nameAr}</span>
                            <span className={`text-[11px] font-bold ${isSelected ? 'text-stone-300' : 'text-stone-400'}`}>
                              ({curr.code})
                            </span>
                          </div>
                          <div className={`text-[10px] ${isSelected ? 'text-stone-300' : 'text-stone-500'}`}>
                            {isEn ? 'Symbol' : 'الرمز'}: <span className="font-bold">{curr.symbol}</span>
                          </div>
                        </div>
                      </div>

                      {isSelected && (
                        <div className="w-6 h-6 rounded-full bg-white text-stone-900 flex items-center justify-center shrink-0">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}

                {filteredCurrencies.length === 0 && (
                  <div className="py-8 text-center text-xs text-stone-400">
                    {isEn ? 'No currencies match your search.' : 'لم يتم العثور على عملة مطابقة.'}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-3 border-t border-stone-100 bg-[#FAF9F6] flex justify-end shrink-0">
                <button
                  type="button"
                  onClick={() => setIsCurrencyPickerOpen(false)}
                  className="px-4 py-1.5 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs transition-colors"
                >
                  {isEn ? 'Done' : 'تم'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
