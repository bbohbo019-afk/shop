import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  ArrowLeft, 
  ShieldCheck, 
  ShoppingBag, 
  MoreVertical, 
  Flag, 
  Ban, 
  MessageSquare,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMessaging } from '../context/MessagingContext';
import { useMarketplace } from '../context/MarketplaceContext';
import { Conversation } from '../types';

interface MessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenReport: (targetType: 'user', targetId: string) => void;
}

export const MessagesModal: React.FC<MessagesModalProps> = ({
  isOpen,
  onClose,
  onOpenReport,
}) => {
  const { user } = useAuth();
  const { 
    conversations, 
    activeConversation, 
    setActiveConversation, 
    messages, 
    sendMessage 
  } = useMessaging();
  const { submitReport } = useMarketplace();

  const [inputMessage, setInputMessage] = useState('');
  const [showMenu, setShowMenu] = useState(false);
  const [blockedNotice, setBlockedNotice] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    const text = inputMessage;
    setInputMessage('');
    await sendMessage(text);
  };

  const handleBlockUser = () => {
    if (!activeConversation) return;
    const otherName = activeConversation.participantNames.find(n => n !== 'You') || 'User';
    setBlockedNotice(`${otherName} has been muted and blocked from messaging you.`);
    setShowMenu(false);
    setTimeout(() => {
      setBlockedNotice(null);
      setActiveConversation(null);
    }, 2000);
  };

  const currentUid = user ? user.uid : 'guest-user';

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex items-center justify-center p-2 sm:p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/50 backdrop-blur-sm"
      />

      {/* Main Chat Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-2xl h-[88vh] bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-slate-100 flex flex-col sm:flex-row"
      >
        {/* Left Side: Conversation List (Visible when no conversation selected on mobile, or always on tablet/desktop) */}
        <div className={`w-full sm:w-72 bg-[#FAF9FC] border-r border-slate-100 flex flex-col ${
          activeConversation ? 'hidden sm:flex' : 'flex'
        }`}>
          {/* List Header */}
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-600" />
              <h3 className="font-display font-bold text-base text-slate-900">
                Direct Inquiries
              </h3>
            </div>
            <button
              onClick={onClose}
              className="sm:hidden w-7 h-7 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-500"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Conversations Scrollable list */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {conversations.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs">
                No active conversations yet. Reach out to a seller to begin an inquiry.
              </div>
            ) : (
              conversations.map((conv) => {
                const partnerName = conv.participantNames.find(n => n !== 'You') || 'Seller';
                const isSelected = activeConversation?.id === conv.id;

                return (
                  <button
                    key={conv.id}
                    onClick={() => setActiveConversation(conv)}
                    className={`w-full text-left p-3 rounded-2xl transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'bg-white shadow-sm border border-slate-200/80'
                        : 'hover:bg-white/60'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm shrink-0">
                      {partnerName.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-xs text-slate-900 truncate">
                          {partnerName}
                        </h4>
                        <span className="text-[10px] text-slate-400">
                          {new Date(conv.lastMessageAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      {conv.productTitle && (
                        <p className="text-[10px] text-indigo-600 font-semibold truncate flex items-center gap-1 mt-0.5">
                          <ShoppingBag className="w-3 h-3 shrink-0" />
                          <span>{conv.productTitle}</span>
                        </p>
                      )}
                      <p className="text-xs text-slate-500 truncate mt-0.5">
                        {conv.lastMessage}
                      </p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Active Chat View */}
        <div className={`flex-1 flex flex-col bg-white ${
          !activeConversation ? 'hidden sm:flex items-center justify-center' : 'flex'
        }`}>
          {!activeConversation ? (
            <div className="text-center p-8 text-slate-400 space-y-2">
              <MessageSquare className="w-12 h-12 stroke-[1.2] mx-auto text-slate-300" />
              <h4 className="font-bold text-slate-700 text-sm">Select a Conversation</h4>
              <p className="text-xs text-slate-400 max-w-xs">
                Communicate directly with verified sellers to agree on custom finishes, specifications, and delivery.
              </p>
            </div>
          ) : (
            <>
              {/* Chat Header */}
              <div className="p-3.5 sm:p-4 border-b border-slate-100 flex items-center justify-between bg-white relative">
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    onClick={() => setActiveConversation(null)}
                    className="sm:hidden w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </button>

                  <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-sm shrink-0">
                    {activeConversation.participantNames.find(n => n !== 'You')?.charAt(0) || 'S'}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                        {activeConversation.participantNames.find(n => n !== 'You') || 'Seller'}
                      </h4>
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    </div>
                    {activeConversation.productTitle ? (
                      <p className="text-[11px] text-indigo-600 font-medium truncate flex items-center gap-1">
                        <ShoppingBag className="w-3 h-3 shrink-0" />
                        <span>Inquiring about: {activeConversation.productTitle}</span>
                      </p>
                    ) : (
                      <p className="text-[10px] text-slate-400">Direct Message Channel</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setShowMenu(!showMenu)}
                    className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-500 flex items-center justify-center"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>
                  <button
                    onClick={onClose}
                    className="hidden sm:flex w-8 h-8 rounded-full hover:bg-slate-100 text-slate-500 items-center justify-center"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  {/* Safety & Moderation Options Dropdown */}
                  {showMenu && (
                    <div className="absolute right-4 top-14 w-44 bg-white rounded-2xl shadow-xl border border-slate-100 p-1.5 z-30 space-y-1">
                      <button
                        onClick={() => {
                          const otherId = activeConversation.participantIds.find(id => id !== currentUid) || 'user';
                          onOpenReport('user', otherId);
                          setShowMenu(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                      >
                        <Flag className="w-3.5 h-3.5 text-amber-500" />
                        <span>Report User</span>
                      </button>
                      <button
                        onClick={handleBlockUser}
                        className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>Block Seller</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {blockedNotice && (
                <div className="p-3 bg-rose-50 text-rose-800 text-xs font-bold text-center">
                  {blockedNotice}
                </div>
              )}

              {/* Message Bubbles History */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#FBFBFC]">
                {messages.length === 0 ? (
                  <div className="text-center py-8 text-slate-400 text-xs">
                    Start your message to request product availability, custom materials, or shipping times.
                  </div>
                ) : (
                  messages.map((msg) => {
                    const isMe = msg.senderId === currentUid || msg.senderName === 'You';

                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[82%] px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-xs ${
                            isMe
                              ? 'bg-slate-900 text-white rounded-br-xs'
                              : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                          }`}
                        >
                          <p>{msg.text}</p>
                        </div>
                        <span className="text-[10px] text-slate-400 mt-1 px-1">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input Bar */}
              <form onSubmit={handleSend} className="p-3 sm:p-4 border-t border-slate-100 bg-white flex items-center gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Type an inquiry or question..."
                  className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:border-indigo-600 transition-all"
                />
                <button
                  type="submit"
                  disabled={!inputMessage.trim()}
                  className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center hover:bg-slate-800 disabled:opacity-40 active:scale-95 transition-all shadow-sm"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
};
