import React from 'react';
import { 
  Heart, 
  Trash2, 
  Star, 
  MessageCircle, 
  Send, 
  Globe, 
  ArrowUpRight,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { Product } from '../types';
import { useMarketplace } from '../context/MarketplaceContext';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onEditStock?: () => void;
  layout?: 'grid' | 'stream';
}

export const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onSelect,
  layout = 'grid'
}) => {
  const { isFavorite, likeProduct, formatPrice, isAdmin, deleteProduct } = useMarketplace();
  const favorited = isFavorite(product.id);
  const isOutOfStock = product.stock !== undefined && product.stock <= 0;

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    likeProduct(product.id);
  };

  const handleDeleteClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(`تأكيد حذف المنتج كأدمن:\n"${product.title}"؟`)) {
      await deleteProduct(product.id);
    }
  };

  const primaryImage = product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800';
  const bgTint = product.backgroundTint || '#F8F7F4';

  // STREAM LAYOUT: Large immersive visual card (ultra-comfort, magazine discovery)
  if (layout === 'stream') {
    return (
      <div
        onClick={() => onSelect(product)}
        className="group relative bg-white rounded-[28px] overflow-hidden border border-stone-200/80 shadow-[0_6px_28px_rgba(20,20,30,0.04)] hover:shadow-[0_16px_44px_rgba(20,20,30,0.08)] transition-all duration-300 cursor-pointer flex flex-col active:scale-[0.99]"
      >
        {/* Upper Image Canvas */}
        <div 
          className="relative w-full aspect-[16/10] sm:aspect-[2/1] overflow-hidden flex items-center justify-center p-6 transition-colors duration-300"
          style={{ backgroundColor: bgTint }}
        >
          {/* Subtle Ambient Radial Highlight */}
          <div className="absolute inset-0 bg-radial from-white/60 via-transparent to-transparent pointer-events-none" />

          {/* Floating Badges Header */}
          <div className="absolute top-3.5 inset-x-3.5 flex items-center justify-between z-10">
            {/* Condition & Stock Pill */}
            <div className="flex items-center gap-1.5">
              {isOutOfStock ? (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-stone-900/90 text-white backdrop-blur-md shadow-xs">
                  نفذت الكمية
                </span>
              ) : product.stock !== undefined && product.stock <= 3 ? (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500 text-white shadow-xs">
                  متبقي {product.stock} فقط
                </span>
              ) : product.condition ? (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-white/90 text-stone-800 backdrop-blur-md shadow-xs border border-stone-200/60">
                  {product.condition}
                </span>
              ) : null}

              {product.isSample && (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-stone-100 text-stone-600">
                  نموذج
                </span>
              )}
            </div>

            {/* Like Button */}
            <button
              onClick={handleHeartClick}
              aria-label="إعجاب"
              className={`h-9 px-3 rounded-full backdrop-blur-md flex items-center gap-1.5 transition-all text-xs font-bold active:scale-90 ${
                favorited
                  ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                  : 'bg-white/90 text-stone-700 hover:text-rose-500 hover:bg-white shadow-xs'
              }`}
            >
              <Heart className={`w-4 h-4 ${favorited ? 'fill-current' : 'stroke-[2.2]'}`} />
              <span>{product.likesCount || (favorited ? 1 : 0)}</span>
            </button>
          </div>

          {/* Admin delete button */}
          {isAdmin && (
            <button
              onClick={handleDeleteClick}
              title="حذف كأدمن"
              className="absolute bottom-3.5 left-3.5 z-10 w-8 h-8 rounded-full bg-rose-600 text-white shadow-md flex items-center justify-center hover:bg-rose-700 active:scale-90 transition-all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}

          {/* Main Product Showcase Image */}
          <img
            src={primaryImage}
            alt={product.title}
            loading="lazy"
            className={`w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-500 ${
              isOutOfStock ? 'grayscale opacity-75' : ''
            }`}
          />
        </div>

        {/* Card Content Information */}
        <div className="p-5 sm:p-6 flex flex-col justify-between flex-1 gap-3.5 bg-white">
          <div>
            {/* Seller Pill & Contact Indicators */}
            <div className="flex items-center justify-between text-xs text-stone-500 mb-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-stone-100 border border-stone-200 overflow-hidden flex items-center justify-center shrink-0">
                  {product.sellerAvatar ? (
                    <img src={product.sellerAvatar} alt={product.sellerName} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-[10px] font-bold text-stone-700">
                      {product.sellerName.charAt(0)}
                    </span>
                  )}
                </div>
                <span className="font-bold text-stone-800 text-xs truncate max-w-[140px]">
                  {product.sellerName}
                </span>
                {product.country && (
                  <span className="text-stone-400 text-[11px]">• {product.country}</span>
                )}
              </div>

              {/* Supported Direct Channels Icons */}
              <div className="flex items-center gap-1.5 text-stone-400">
                {product.whatsapp && <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />}
                {product.telegram && <Send className="w-3.5 h-3.5 text-sky-600" />}
                {product.websiteUrl && <Globe className="w-3.5 h-3.5 text-stone-600" />}
              </div>
            </div>

            {/* Product Title */}
            <h3 className={`font-bold text-base sm:text-lg leading-snug line-clamp-2 transition-colors ${
              isOutOfStock ? 'line-through text-stone-400' : 'text-stone-900 group-hover:text-stone-700'
            }`}>
              {product.title}
            </h3>

            {/* Description Snippet */}
            {product.description && (
              <p className="text-xs text-stone-500 line-clamp-2 mt-1 leading-relaxed">
                {product.description}
              </p>
            )}
          </div>

          {/* Footer: Price and Explore Button */}
          <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                السعر المطلوب
              </span>
              <span className="font-display font-black text-lg sm:text-xl text-stone-900 tracking-tight">
                {formatPrice(product.price, product.currency)}
              </span>
            </div>

            <button className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-stone-900 group-hover:bg-stone-800 text-white font-bold text-xs sm:text-sm shadow-sm transition-all active:scale-95">
              <span>عرض والتواصل</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // GRID LAYOUT: Comfortable, spacious dual-column card (organic, soft on the eyes)
  return (
    <div
      onClick={() => onSelect(product)}
      className={`group relative bg-white rounded-[24px] sm:rounded-[26px] p-3 border border-stone-200/70 shadow-[0_4px_22px_rgba(20,20,30,0.035)] hover:shadow-[0_14px_36px_rgba(20,20,30,0.075)] hover:border-stone-300 active:scale-[0.985] transition-all duration-200 cursor-pointer flex flex-col justify-between ${
        isOutOfStock ? 'opacity-85' : ''
      }`}
    >
      {/* Upper Area: Comfortable product canvas with soft ambient background */}
      <div 
        className="relative w-full aspect-square sm:aspect-[4/3] rounded-[18px] sm:rounded-[20px] overflow-hidden flex items-center justify-center p-3 transition-colors duration-300"
        style={{ backgroundColor: bgTint }}
      >
        {/* Interactive Floating Like Button */}
        <button
          onClick={handleHeartClick}
          aria-label="إعجاب"
          className={`absolute top-2 right-2 z-10 h-7 px-2 rounded-full backdrop-blur-md flex items-center gap-1 transition-all text-[11px] font-bold active:scale-90 ${
            favorited
              ? 'bg-rose-500 text-white shadow-xs'
              : 'bg-white/90 text-stone-700 hover:text-rose-500 hover:bg-white shadow-xs'
          }`}
        >
          <Heart className={`w-3.5 h-3.5 ${favorited ? 'fill-current' : 'stroke-[2.2]'}`} />
          <span>{product.likesCount || (favorited ? 1 : 0)}</span>
        </button>

        {/* Condition or Stock Badge */}
        <div className="absolute top-2 left-2 z-10 flex flex-col gap-1">
          {isOutOfStock ? (
            <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-stone-900/90 text-white backdrop-blur-md">
              نفذت الكمية
            </span>
          ) : product.stock !== undefined && product.stock <= 3 ? (
            <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500 text-white shadow-xs">
              متبقي {product.stock}
            </span>
          ) : product.condition ? (
            <span className="px-2 py-0.5 rounded-full text-[9px] font-semibold bg-white/90 text-stone-700 backdrop-blur-md shadow-xs border border-stone-200/40">
              {product.condition}
            </span>
          ) : null}
        </div>

        {/* Admin Quick Delete */}
        {isAdmin && (
          <button
            onClick={handleDeleteClick}
            title="حذف كأدمن"
            className="absolute bottom-2 left-2 z-10 w-7 h-7 rounded-full bg-rose-600 text-white shadow-xs flex items-center justify-center hover:bg-rose-700 active:scale-90 transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        )}

        {/* Product Image */}
        <img
          src={primaryImage}
          alt={product.title}
          loading="lazy"
          className={`w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-300 ${
            isOutOfStock ? 'grayscale opacity-75' : ''
          }`}
        />
      </div>

      {/* Product Information Body */}
      <div className="pt-2.5 px-1 flex flex-col justify-between flex-1 gap-1.5">
        <div>
          {/* Seller / Verified Tag */}
          <div className="flex items-center justify-between text-[11px] text-stone-400 font-medium">
            <span className="truncate max-w-[110px] text-stone-600 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
              {product.sellerName}
            </span>

            {product.rating ? (
              <span className="flex items-center gap-0.5 text-amber-600 font-bold text-[10px]">
                <Star className="w-3 h-3 fill-amber-400 stroke-amber-500" />
                {product.rating.toFixed(1)}
              </span>
            ) : (
              <span className="text-[10px] text-stone-400">
                {product.stock !== undefined && product.stock > 0 ? 'جاهز للطلب' : ''}
              </span>
            )}
          </div>

          {/* Product Title */}
          <h3 className={`font-bold text-xs sm:text-sm leading-snug line-clamp-2 mt-1 transition-colors ${
            isOutOfStock ? 'line-through text-stone-400' : 'text-stone-900 group-hover:text-stone-700'
          }`}>
            {product.title}
          </h3>
        </div>

        {/* Price & Action Row */}
        <div className="pt-2 border-t border-stone-100/90 flex items-center justify-between mt-auto">
          <div className="flex flex-col">
            <span className="text-[9px] uppercase font-bold text-stone-400 leading-none">
              السعر
            </span>
            <span className="font-display font-black text-sm sm:text-base text-stone-900 tracking-tight mt-0.5">
              {formatPrice(product.price, product.currency)}
            </span>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-bold text-stone-800 bg-stone-100 group-hover:bg-stone-900 group-hover:text-white px-2.5 py-1.5 rounded-xl transition-all">
            <span>عرض</span>
          </div>
        </div>
      </div>
    </div>
  );
};
