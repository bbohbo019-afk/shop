import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  X, 
  Upload, 
  Image as ImageIcon, 
  Tag, 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles,
  User
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useMarketplace } from '../context/MarketplaceContext';
import { Product } from '../types';

interface PublishPostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAuth: () => void;
}

export const PublishPostModal: React.FC<PublishPostModalProps> = ({
  isOpen,
  onClose,
  onOpenAuth,
}) => {
  const { user, userProfile } = useAuth();
  const { products, createPostPublication } = useMarketplace();

  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [taggedProduct, setTaggedProduct] = useState<Product | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) setImageUrl(result);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!user) {
      onOpenAuth();
      return;
    }

    if (!content.trim()) {
      setError('Please write some content for your community post.');
      return;
    }

    setLoading(true);
    try {
      await createPostPublication(content.trim(), imageUrl || undefined, taggedProduct);
      setSuccess(true);
      setTimeout(() => {
        onClose();
      }, 1400);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to publish post.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/50 backdrop-blur-sm"
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-slate-100 my-8"
      >
        <div className="p-5 border-b border-slate-100 bg-[#FAF9FC] flex items-center justify-between">
          <div>
            <h2 className="font-display font-bold text-lg text-slate-900">
              Publish Community Post
            </h2>
            <p className="text-xs text-slate-500">
              Share crafting insights, product highlights, or behind-the-scenes
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-slate-200 shadow-xs flex items-center justify-center text-slate-500 hover:text-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {!user && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between gap-3">
              <span>Sign in with a verified account to publish community posts.</span>
              <button
                type="button"
                onClick={onOpenAuth}
                className="px-3 py-1.5 rounded-xl bg-slate-900 text-white font-bold text-xs shrink-0"
              >
                Sign In
              </button>
            </div>
          )}

          {error && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span className="font-bold">Post shared successfully to community feed!</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* User header */}
            {user && (
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 font-bold flex items-center justify-center text-sm">
                  {userProfile?.displayName?.charAt(0) || user.displayName?.charAt(0) || 'U'}
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900">
                    {userProfile?.displayName || user.displayName || 'Marketplace Member'}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Posting publicly to global marketplace feed
                  </p>
                </div>
              </div>
            )}

            {/* Text content */}
            <div>
              <textarea
                rows={4}
                required
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="What are you creating or discovering today? Share your thoughts, materials, or craftsmanship..."
                className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:outline-none focus:border-indigo-600 transition-all"
              />
            </div>

            {/* Tag product listing */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-indigo-600" />
                <span>Tag a Marketplace Product (Optional)</span>
              </label>
              <select
                value={taggedProduct?.id || ''}
                onChange={(e) => {
                  const found = products.find(p => p.id === e.target.value);
                  setTaggedProduct(found);
                }}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-indigo-600"
              >
                <option value="">No product tagged</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} ({p.sellerName}) - ${p.price}
                  </option>
                ))}
              </select>
            </div>

            {/* Image attachment */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
                Attach Image (Upload or URL)
              </label>
              <div className="flex gap-2">
                <label className="cursor-pointer flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold shrink-0">
                  <Upload className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Upload</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="Or paste image URL"
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              {imageUrl && (
                <div className="mt-2 relative w-full h-36 rounded-xl overflow-hidden border border-slate-200">
                  <img src={imageUrl} alt="preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setImageUrl('')}
                    className="absolute top-2 right-2 w-7 h-7 rounded-full bg-slate-900/70 text-white flex items-center justify-center text-xs"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Submit */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={loading || !user}
                className="w-full py-3 px-4 rounded-2xl bg-slate-950 text-white font-bold text-xs sm:text-sm hover:bg-slate-800 shadow-md shadow-slate-950/10 active:scale-98 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Publish Post</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};
