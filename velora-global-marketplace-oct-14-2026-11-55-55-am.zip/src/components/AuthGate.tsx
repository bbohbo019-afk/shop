import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  Lock, 
  User, 
  AtSign, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  Sparkles,
  Layers,
  Hexagon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BrandLogo } from './BrandLogo';

export const AuthGate: React.FC = () => {
  const { signInWithEmail, signUpWithEmail, signInWithGoogle, resetPassword } = useAuth();

  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgot, setIsForgot] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessNotice(null);
    setLoading(true);

    try {
      if (isForgot) {
        if (!email.trim()) throw new Error('الرجاء إدخال البريد الإلكتروني لاستعادة الحساب.');
        await resetPassword(email.trim());
        setSuccessNotice('تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني.');
      } else if (isSignUp) {
        if (!displayName.trim()) throw new Error('يرجى إدخال الاسم بالكامل.');
        if (!username.trim() || username.length < 3) throw new Error('اسم المستخدم يجب أن يكون 3 أحرف على الأقل.');
        if (password.length < 6) throw new Error('كلمة المرور يجب أن لا تقل عن 6 أحرف.');
        if (password !== confirmPassword) throw new Error('كلمتا المرور غير متطابقتين.');

        await signUpWithEmail(email.trim(), password, displayName.trim(), username.trim().toLowerCase());
        setSuccessNotice('تم إنشاء حسابك بنجاح! جاري الدخول...');
      } else {
        await signInWithEmail(email.trim(), password);
        setSuccessNotice('مرحباً بك مجدداً!');
      }
    } catch (err: any) {
      console.error(err);
      let msg = err.message || 'حدث خطأ في التسجيل، يرجى المحاولة ثانية.';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'هذا البريد الإلكتروني مسجل مسبقاً، يرجى تسجيل الدخول.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'كلمة المرور ضعيفة، يجب أن تحتوي على 6 خانات على الأقل.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithGoogle();
      setSuccessNotice('تم تسجيل الدخول بنجاح عبر Google');
    } catch (err: any) {
      setError(err.message || 'تعذر تسجيل الدخول عبر Google.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F7F4] flex flex-col items-center justify-center p-4 relative overflow-hidden select-none">
      {/* Background Geometric Vector Blueprint Pattern (Comfortable for the eye) */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.035]">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="geometricGrid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 48 0 L 0 0 0 48" fill="none" stroke="#18181B" strokeWidth="1" />
              <circle cx="24" cy="24" r="2" fill="#18181B" />
              <polygon points="24,14 34,24 24,34 14,24" fill="none" stroke="#18181B" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#geometricGrid)" />
        </svg>
      </div>

      {/* Floating subtle ambient geometric shapes */}
      <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-stone-200/50 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-stone-300/40 blur-3xl pointer-events-none" />

      {/* Main Geometric Card Container */}
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.35, ease: 'easeOut' }}
        className="relative w-full max-w-md bg-white rounded-3xl shadow-[0_12px_40px_rgba(0,0,0,0.06)] border border-stone-200/90 overflow-hidden z-10"
      >
        {/* Top Geometric Illustration & Header */}
        <div className="pt-8 pb-5 px-6 text-center border-b border-stone-100 bg-[#FAF9F6]">
          {/* Brand Logo Symbol */}
          <div className="flex flex-col items-center justify-center mb-3">
            <BrandLogo size={54} />
            <span className="font-display font-black text-sm tracking-tight text-stone-900 mt-2">
              AIUS<span className="text-sky-600">HUB</span>
            </span>
          </div>

          <h1 className="font-display font-extrabold text-xl text-stone-900 tracking-tight">
            {isForgot ? 'استعادة الحساب' : isSignUp ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}
          </h1>
          <p className="text-xs text-stone-500 font-medium mt-1">
            {isForgot
              ? 'أدخل بريدك الإلكتروني لاستلام رابط الاسترجاع'
              : isSignUp
              ? 'سجل حسابك لتصفح ونشر المنتجات والتواصل المباشر'
              : 'مرحباً بك في السوق، يرجى تسجيل الدخول للمتابعة'}
          </p>

          {/* Clean Geometric Segmented Toggle */}
          {!isForgot && (
            <div className="flex bg-stone-100/90 p-1 rounded-2xl mt-4 border border-stone-200/60">
              <button
                type="button"
                onClick={() => { setIsSignUp(false); setError(null); }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  !isSignUp
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                تسجيل الدخول
              </button>
              <button
                type="button"
                onClick={() => { setIsSignUp(true); setError(null); }}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                  isSignUp
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                حساب جديد
              </button>
            </div>
          )}
        </div>

        {/* Form Body */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <p className="leading-relaxed font-medium">{error}</p>
            </div>
          )}

          {successNotice && (
            <div className="mb-4 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <p className="leading-relaxed font-medium">{successNotice}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Registration Specific Fields */}
            {isSignUp && !isForgot && (
              <>
                <div>
                  <label className="block text-[11px] font-bold text-stone-600 mb-1">
                    الاسم بالكامل أو اسم المتجر
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="مثال: متجر النور أو أحمد علي"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:bg-white focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-stone-600 mb-1">
                    اسم المستخدم الفريد (معرف الحساب)
                  </label>
                  <div className="relative">
                    <AtSign className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, ''))}
                      placeholder="username"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:bg-white focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900 transition-all"
                    />
                  </div>
                </div>
              </>
            )}

            {/* Email Field */}
            <div>
              <label className="block text-[11px] font-bold text-stone-600 mb-1">
                البريد الإلكتروني
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:bg-white focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900 transition-all"
                />
              </div>
            </div>

            {/* Password Field */}
            {!isForgot && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-[11px] font-bold text-stone-600">
                    كلمة المرور
                  </label>
                  {!isSignUp && (
                    <button
                      type="button"
                      onClick={() => { setIsForgot(true); setError(null); }}
                      className="text-[11px] font-semibold text-stone-500 hover:text-stone-900"
                    >
                      نسيت كلمة المرور؟
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:bg-white focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3 text-stone-400 hover:text-stone-700"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Password Confirmation */}
            {isSignUp && !isForgot && (
              <div>
                <label className="block text-[11px] font-bold text-stone-600 mb-1">
                  تأكيد كلمة المرور
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:bg-white focus:outline-none focus:border-stone-900 focus:ring-1 focus:ring-stone-900 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3.5 top-3 text-stone-400 hover:text-stone-700"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Primary Action Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 rounded-2xl bg-stone-900 text-white font-bold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 hover:bg-stone-800 shadow-md shadow-stone-900/10 active:scale-98 disabled:opacity-50 transition-all"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>
                    {isForgot ? 'إرسال رابط الاستعادة' : isSignUp ? 'إنشاء الحساب والدخول' : 'تسجيل الدخول'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            {isForgot && (
              <button
                type="button"
                onClick={() => { setIsForgot(false); setError(null); }}
                className="w-full text-center text-xs font-semibold text-stone-500 hover:text-stone-900 py-1"
              >
                العودة لتسجيل الدخول
              </button>
            )}

            {/* Quick Google Sign In */}
            {!isForgot && (
              <>
                <div className="relative my-3">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-stone-200" />
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="bg-white px-2.5 text-stone-400 font-medium">أو عبر</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={loading}
                  className="w-full py-2.5 px-4 rounded-2xl border border-stone-200/90 bg-white hover:bg-stone-50 text-stone-700 font-semibold text-xs flex items-center justify-center gap-2.5 active:scale-98 transition-all"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>المتابعة باستخدام Google</span>
                </button>
              </>
            )}
          </form>
        </div>
      </motion.div>
    </div>
  );
};
