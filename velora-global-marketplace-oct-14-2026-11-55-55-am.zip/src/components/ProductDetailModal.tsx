import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Heart, 
  Share2, 
  ShoppingBag, 
  Plus, 
  Minus, 
  MessageSquare, 
  ExternalLink, 
  Trash2, 
  Edit3, 
  Check, 
  AlertCircle
} from 'lucide-react';
import { Product } from '../types';
import { useMarketplace } from '../context/MarketplaceContext';
import { useAuth } from '../context/AuthContext';
import { useMessaging } from '../context/MessagingContext';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose }) => {
  const { user } = useAuth();
  const { 
    isFavorite, 
    likeProduct, 
    addToCart, 
    formatPrice, 
    updateProductStock, 
    deleteProduct, 
    isAdmin 
  } = useMarketplace();
  const { startConversation } = useMessaging();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedNotice, setAddedNotice] = useState(false);
  
  // Seller inline stock editing state
  const [isEditingStock, setIsEditingStock] = useState(false);
  const [newStockInput, setNewStockInput] = useState<number>(product?.stock !== undefined ? product.stock : 1);
  const [stockUpdating, setStockUpdating] = useState(false);

  if (!product) return null;

  const favorited = isFavorite(product.id);
  const images = product.images?.length > 0 ? product.images : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800'];
  const isOwner = user && user.uid === product.sellerId;
  const isOutOfStock = product.stock !== undefined && product.stock <= 0;

  const handleLike = () => {
    likeProduct(product.id);
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  const handleSaveStock = async () => {
    setStockUpdating(true);
    try {
      await updateProductStock(product.id, newStockInput);
      setIsEditingStock(false);
    } catch (err) {
      console.error(err);
      alert('تعذر تحديث الكمية، يرجى المحاولة ثانية.');
    } finally {
      setStockUpdating(false);
    }
  };

  const handleDelete = async () => {
    if (confirm(`هل أنت متأكد من حذف المنتج: "${product.title}"؟`)) {
      await deleteProduct(product.id);
      onClose();
    }
  };

  const handleStartInAppChat = async () => {
    await startConversation(product.sellerId, product.sellerName, product);
    onClose();
  };

  // WhatsApp link preparation
  const getWhatsAppUrl = () => {
    const rawNumber = (product.whatsapp || product.contactInfo || '').replace(/[^0-9]/g, '');
    const text = encodeURIComponent(`مرحباً! أود الاستفسار عن منتجك في السوق: "${product.title}"`);
    return `https://wa.me/${rawNumber}?text=${text}`;
  };

  // Telegram link preparation
  const getTelegramUrl = () => {
    const raw = (product.telegram || '').replace('@', '').trim();
    return `https://t.me/${raw}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex flex-col justify-end sm:justify-center items-center">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-stone-950/50 backdrop-blur-xs"
      />

      {/* Modal Container */}
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 280 }}
        className="relative w-full max-w-xl h-[92vh] sm:h-[88vh] bg-white rounded-t-[32px] sm:rounded-[32px] shadow-2xl flex flex-col z-10 overflow-hidden border border-stone-200/80"
      >
        {/* Floating Top Nav (Back, Heart, Delete) */}
        <div className="absolute top-4 inset-x-4 z-30 flex items-center justify-between pointer-events-none">
          <button
            onClick={onClose}
            aria-label="الرجوع"
            className="pointer-events-auto w-10 h-10 rounded-full bg-white/90 backdrop-blur-md border border-stone-200/90 shadow-xs flex items-center justify-center text-stone-800 hover:bg-white active:scale-95 transition-all"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.2]" />
          </button>

          <div className="flex items-center gap-2 pointer-events-auto">
            {/* Delete button for Admin or Owner */}
            {(isAdmin || isOwner) && (
              <button
                onClick={handleDelete}
                aria-label="حذف المنتج"
                title="حذف هذا المنتج"
                className="w-10 h-10 rounded-full bg-rose-50 border border-rose-200 shadow-xs flex items-center justify-center text-rose-600 hover:bg-rose-100 active:scale-95 transition-all"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            {/* Like button with count */}
            <button
              onClick={handleLike}
              aria-label="إعجاب"
              className={`h-10 px-3.5 rounded-full backdrop-blur-md border shadow-xs flex items-center gap-1.5 transition-all text-xs font-bold ${
                favorited
                  ? 'bg-rose-500 border-rose-500 text-white'
                  : 'bg-white/90 border-stone-200/90 text-stone-700 hover:text-rose-500'
              }`}
            >
              <Heart className={`w-4 h-4 ${favorited ? 'fill-current' : 'stroke-[2.2]'}`} />
              <span>{product.likesCount || (favorited ? 1 : 0)}</span>
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto no-scrollbar">
          {/* Hero Image Section */}
          <div className="relative w-full h-72 sm:h-80 bg-[#F6F5F2] flex items-center justify-center p-6 border-b border-stone-100">
            <img
              src={images[activeImageIndex]}
              alt={product.title}
              className={`max-h-60 sm:max-h-68 w-auto object-contain mix-blend-multiply select-none transition-all duration-200 ${
                isOutOfStock ? 'grayscale opacity-75' : ''
              }`}
            />

            {/* Gallery Dots */}
            {images.length > 1 && (
              <div className="absolute bottom-3 inset-x-0 flex items-center justify-center gap-1.5 z-10">
                {images.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`h-1.5 rounded-full transition-all ${
                      activeImageIndex === idx ? 'w-5 bg-stone-900' : 'w-1.5 bg-stone-300'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Details Body */}
          <div className="p-5 sm:p-6 space-y-5">
            {/* Title & Price Header */}
            <div>
              <div className="flex items-center justify-between text-xs text-stone-400 font-medium mb-1">
                <span>{product.category}</span>
                {isOutOfStock ? (
                  <span className="px-2 py-0.5 rounded-full bg-stone-900 text-white font-bold text-[10px]">
                    نفذت الكمية
                  </span>
                ) : product.stock !== undefined ? (
                  <span className="font-semibold text-stone-600 text-xs">
                    متبقي: {product.stock} قطع
                  </span>
                ) : null}
              </div>

              <h2 className={`font-display font-extrabold text-xl sm:text-2xl tracking-tight leading-tight ${
                isOutOfStock ? 'line-through text-stone-400' : 'text-stone-900'
              }`}>
                {product.title}
              </h2>

              <div className="mt-2 text-xl sm:text-2xl font-black text-stone-900 font-display">
                {formatPrice(product.price, product.currency)}
              </div>
            </div>

            {/* SELLER ONLY: Stock Editor ("التعديل يكون فقط كم باقي قطع من المنتج") */}
            {isOwner && (
              <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-stone-500" />
                    <span>تعديل الكمية المتبقية (خاص بك كبائع)</span>
                  </span>
                  {!isEditingStock ? (
                    <button
                      onClick={() => {
                        setNewStockInput(product.stock !== undefined ? product.stock : 1);
                        setIsEditingStock(true);
                      }}
                      className="text-xs font-bold text-stone-900 underline hover:text-stone-700"
                    >
                      تغيير
                    </button>
                  ) : null}
                </div>

                {isEditingStock ? (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="number"
                      min="0"
                      value={newStockInput}
                      onChange={(e) => setNewStockInput(parseInt(e.target.value) || 0)}
                      className="w-24 px-3 py-1.5 bg-white border border-stone-300 rounded-xl text-xs font-bold text-stone-900"
                    />
                    <button
                      onClick={handleSaveStock}
                      disabled={stockUpdating}
                      className="px-3.5 py-1.5 rounded-xl bg-stone-900 text-white font-bold text-xs hover:bg-stone-800 disabled:opacity-50"
                    >
                      {stockUpdating ? 'جاري الحفظ...' : 'حفظ'}
                    </button>
                    <button
                      onClick={() => setIsEditingStock(false)}
                      className="px-3 py-1.5 rounded-xl border border-stone-200 text-stone-600 text-xs font-bold hover:bg-white"
                    >
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <p className="text-[11px] text-stone-500">
                    الكمية المعروضة حالياً: <strong className="text-stone-900 font-bold">{product.stock !== undefined ? product.stock : 1}</strong> قطعة. إذا أصبحت 0 سيظهر خط على العنوان ويُعلم الزبائن بنفاذها.
                  </p>
                )}
              </div>
            )}

            {/* DIRECT CONTACT CHANNELS (WhatsApp, Telegram, Website, In-app Chat) */}
            <div className="space-y-2 pt-1">
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-500">
                طرق التواصل مع البائع
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {/* WhatsApp */}
                {(product.whatsapp || product.contactPreference === 'WhatsApp') && (
                  <a
                    href={getWhatsAppUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-2xl bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                        W
                      </div>
                      <span>تواصل عبر واتساب</span>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-emerald-600" />
                  </a>
                )}

                {/* Telegram */}
                {product.telegram && (
                  <a
                    href={getTelegramUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-2xl bg-sky-50 hover:bg-sky-100/80 border border-sky-200 text-sky-900 text-xs font-bold flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-sky-500 text-white flex items-center justify-center font-bold text-xs">
                        T
                      </div>
                      <span>تواصل عبر تليجرام</span>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-sky-600" />
                  </a>
                )}

                {/* External Website */}
                {product.websiteUrl && (
                  <a
                    href={product.websiteUrl.startsWith('http') ? product.websiteUrl : `https://${product.websiteUrl}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-2xl bg-stone-100 hover:bg-stone-200/80 border border-stone-200 text-stone-900 text-xs font-bold flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-stone-800 text-white flex items-center justify-center font-bold text-xs">
                        🌐
                      </div>
                      <span>الموقع الرسمي للمنتج</span>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-stone-600" />
                  </a>
                )}

                {/* Internal In-App Chat */}
                <button
                  onClick={handleStartInAppChat}
                  className="p-3 rounded-2xl bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-900 text-xs font-bold flex items-center justify-between transition-all"
                >
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-stone-600" />
                    <span>مراسلة البائع داخل التطبيق</span>
                  </div>
                  <ArrowLeft className="w-3.5 h-3.5 text-stone-400 rotate-180" />
                </button>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1.5 pt-2 border-t border-stone-100">
              <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                وصف المنتج
              </h4>
              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed whitespace-pre-line">
                {product.description}
              </p>
            </div>

            {/* Seller profile badge */}
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-stone-400 uppercase font-bold">البائع</span>
                <h5 className="font-bold text-xs text-stone-900">{product.sellerName}</h5>
              </div>
              <span className="text-[11px] font-semibold text-stone-500">
                {product.city ? `${product.city}, ` : ''}{product.country || 'عالمي'}
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Action Bar */}
        <div className="p-4 bg-white border-t border-stone-100 flex items-center gap-3">
          {/* Quantity Selector */}
          <div className="flex items-center gap-2 bg-stone-100 rounded-2xl p-1 border border-stone-200/70">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="w-8 h-8 rounded-xl bg-white shadow-xs flex items-center justify-center text-stone-700 active:scale-95"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="w-6 text-center text-xs font-bold text-stone-900">
              {quantity}
            </span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="w-8 h-8 rounded-xl bg-white shadow-xs flex items-center justify-center text-stone-700 active:scale-95"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Add to Inquiry Cart Button */}
          <button
            onClick={handleAddToCart}
            className="flex-1 py-3.5 px-4 rounded-2xl bg-stone-900 text-white font-bold text-xs sm:text-sm hover:bg-stone-800 shadow-md shadow-stone-900/10 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{addedNotice ? 'تمت الإضافة للسلة!' : 'إضافة لسلة الاستفسارات'}</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
