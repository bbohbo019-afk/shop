import React, { useState, useMemo } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MarketplaceProvider, useMarketplace } from './context/MarketplaceContext';
import { MessagingProvider } from './context/MessagingContext';
import { Header } from './components/Header';
import { NavigationDrawer } from './components/NavigationDrawer';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { AuthGate } from './components/AuthGate';
import { CartDrawer } from './components/CartDrawer';
import { PublishProductModal } from './components/PublishProductModal';
import { MessagesModal } from './components/MessagesModal';
import { SettingsModal } from './components/SettingsModal';
import { LikedProductsModal } from './components/LikedProductsModal';
import { MyListingsModal } from './components/MyListingsModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { Product } from './types';
import { 
  SlidersHorizontal, 
  Heart, 
  Sparkles, 
  PackageCheck
} from 'lucide-react';

function MarketplaceMain() {
  const { user, loading: authLoading } = useAuth();
  const { 
    products, 
    searchQuery, 
    isAdmin
  } = useMarketplace();

  // Navigation & Modals state
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isPublishProductOpen, setIsPublishProductOpen] = useState(false);
  const [isMessagesOpen, setIsMessagesOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLikedOpen, setIsLikedOpen] = useState(false);
  const [isMyListingsOpen, setIsMyListingsOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);

  // Active Selected Product for Detail View
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Quick Sort Filter: 'all' | 'most-liked' | 'in-stock' | 'newest'
  const [activeSort, setActiveSort] = useState<'all' | 'most-liked' | 'in-stock' | 'newest'>('all');

  // Filter products by search query and sort
  const filteredProducts = useMemo(() => {
    let result = products.filter((item) => {
      // Search matching
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = item.title.toLowerCase().includes(q);
        const matchesDesc = item.description?.toLowerCase().includes(q);
        const matchesSeller = item.sellerName?.toLowerCase().includes(q);
        if (!matchesTitle && !matchesDesc && !matchesSeller) {
          return false;
        }
      }

      // In-stock filter
      if (activeSort === 'in-stock') {
        return item.stock === undefined || item.stock > 0;
      }

      return true;
    });

    // Most Liked Sorting
    if (activeSort === 'most-liked') {
      result = [...result].sort((a, b) => (b.likesCount || 0) - (a.likesCount || 0));
    } else if (activeSort === 'newest') {
      result = [...result].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return result;
  }, [products, searchQuery, activeSort]);

  // Loading state
  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#F7F6F2] flex items-center justify-center">
        <div className="w-8 h-8 border-3 border-stone-300 border-t-stone-900 rounded-full animate-spin" />
      </div>
    );
  }

  // MANDATORY AUTHENTICATION GATE SCREEN: If not logged in, user MUST sign up or log in
  if (!user) {
    return <AuthGate />;
  }

  return (
    <div className="min-h-screen bg-[#F7F6F2] text-stone-900 flex flex-col antialiased selection:bg-stone-200">
      {/* Clean Top Header (No logo/name on top, has ... menu and small search + cart) */}
      <Header
        onOpenMenu={() => setIsMenuOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Main Screen: Product Feed */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-3.5 sm:px-4 py-3 sm:py-4 space-y-4">
        
        {/* FEED CONTROLS BAR: Soft filter pills (No product count, no manual layout toggling) */}
        <div className="flex items-center justify-start gap-2 overflow-x-auto py-1 scrollbar-none text-xs font-bold">
          <button
            onClick={() => setActiveSort('all')}
            className={`px-3.5 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeSort === 'all'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'bg-white hover:bg-stone-100 text-stone-600 border border-stone-200/80'
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setActiveSort('most-liked')}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeSort === 'most-liked'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'bg-white hover:bg-stone-100 text-stone-600 border border-stone-200/80'
            }`}
          >
            <Heart className="w-3.5 h-3.5 text-rose-500" />
            <span>الأكثر إعجاباً</span>
          </button>
          <button
            onClick={() => setActiveSort('in-stock')}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeSort === 'in-stock'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'bg-white hover:bg-stone-100 text-stone-600 border border-stone-200/80'
            }`}
          >
            <PackageCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>المتوفر فقط</span>
          </button>
          <button
            onClick={() => setActiveSort('newest')}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeSort === 'newest'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'bg-white hover:bg-stone-100 text-stone-600 border border-stone-200/80'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>وصل حديثاً</span>
          </button>
        </div>

        {/* PRODUCTS FEED:
            - Mobile: 1 product per row (single box with picture and details - "الخيار الثاني")
            - Horizontal / iPad / Computer: Multi-column grid ("الخيار الاول")
            - No manual user selection required!
        */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center bg-white rounded-3xl border border-stone-200/80 p-8 space-y-3 shadow-xs">
            <SlidersHorizontal className="w-10 h-10 text-stone-300 mx-auto" />
            <h3 className="font-bold text-stone-800 text-sm">لا توجد منتجات مطابقة للبحث</h3>
            <p className="text-xs text-stone-400 max-w-xs mx-auto">
              جرب تغيير كلمات البحث أو اختر "الكل" لعرض كافة المنتجات المتوفرة.
            </p>
            <button
              onClick={() => setActiveSort('all')}
              className="px-4 py-2 rounded-xl bg-stone-900 text-white text-xs font-bold hover:bg-stone-800 transition-all"
            >
              عرض كل المنتجات
            </button>
          </div>
        ) : (
          <>
            {/* MOBILE VIEW (Phones): Single Card per Row (الخيار الثاني: مربع كامل لكل منتج مع الصورة والمعلومات) */}
            <div className="block sm:hidden space-y-3.5">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={`m-${product.id}`}
                  product={product}
                  layout="stream"
                  onSelect={(p) => setSelectedProduct(p)}
                  onEditStock={() => setIsMyListingsOpen(true)}
                />
              ))}
            </div>

            {/* TABLET / IPAD / PC HORIZONTAL VIEW: Multi-Column Grid (الخيار الأول: شبكة متعددة الأعمدة) */}
            <div className="hidden sm:grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={`d-${product.id}`}
                  product={product}
                  layout="grid"
                  onSelect={(p) => setSelectedProduct(p)}
                  onEditStock={() => setIsMyListingsOpen(true)}
                />
              ))}
            </div>
          </>
        )}
      </main>

      {/* MODALS & DRAWERS */}
      {/* Side Menu Drawer (Opened from ...) */}
      <NavigationDrawer
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onOpenPublishProduct={() => setIsPublishProductOpen(true)}
        onOpenFavorites={() => setIsLikedOpen(true)}
        onOpenMessages={() => setIsMessagesOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenMyListings={() => setIsMyListingsOpen(true)}
        onOpenAdminPanel={isAdmin ? () => setIsAdminPanelOpen(true) : undefined}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />

      {/* Inquiry Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onOpenMessages={() => setIsMessagesOpen(true)}
      />

      {/* Publish Product Modal */}
      <PublishProductModal
        isOpen={isPublishProductOpen}
        onClose={() => setIsPublishProductOpen(false)}
      />

      {/* Liked Products Modal */}
      <LikedProductsModal
        isOpen={isLikedOpen}
        onClose={() => setIsLikedOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      {/* My Listings & Stock Editor Modal */}
      <MyListingsModal
        isOpen={isMyListingsOpen}
        onClose={() => setIsMyListingsOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      {/* Direct Inquiries & Messaging Modal */}
      <MessagesModal
        isOpen={isMessagesOpen}
        onClose={() => setIsMessagesOpen(false)}
        onOpenReport={() => {}}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* Secret Admin Panel (Only for cl4sc4@gmail.com) */}
      {isAdmin && (
        <AdminPanelModal
          isOpen={isAdminPanelOpen}
          onClose={() => setIsAdminPanelOpen(false)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MarketplaceProvider>
        <MessagingProvider>
          <MarketplaceMain />
        </MessagingProvider>
      </MarketplaceProvider>
    </AuthProvider>
  );
}
