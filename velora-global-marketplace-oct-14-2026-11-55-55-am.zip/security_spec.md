# Security Specification: AURA Global Marketplace

## 1. Data Invariants
1. **User Identity Invariant**: A user profile document `/users/{userId}` can only be created and updated by the authenticated user whose `request.auth.uid == userId`.
2. **Product Ownership Invariant**: A product document `/products/{productId}` can only be created by an authenticated user where `incoming().sellerId == request.auth.uid`. Only the seller can update or delete their product.
3. **Immutable Identity Invariant**: `sellerId` and `createdAt` cannot be modified after creation.
4. **Post Ownership Invariant**: A post document `/posts/{postId}` can only be authored by `request.auth.uid == incoming().authorId`.
5. **Private Conversation Access Invariant**: A conversation `/conversations/{conversationId}` can only be read or written by users whose UID is inside `participantIds` list (maximum 2 participants).
6. **Message Subcollection Gate**: Messages `/conversations/{conversationId}/messages/{messageId}` require the author to be a participant of the parent conversation, and `incoming().senderId == request.auth.uid`.
7. **Favorite Ownership Invariant**: A favorite bookmark `/favorites/{favoriteId}` can only be managed by its owner (`userId == request.auth.uid`).
8. **Report Submissions**: Any authenticated user can submit a report where `reporterId == request.auth.uid`. Users cannot read other users' reports.
9. **Global Safety Net**: Catch-all default deny on all undocumented paths.

## 2. The "Dirty Dozen" Attack Vectors
1. **Ghost Field Injection**: Attempt to inject `isAdmin: true` or `isVerified: true` into a user profile.
2. **Seller Identity Spoofing**: User A creates a product listing with `sellerId = "User_B"`.
3. **Cross-User Modification**: User B attempts to edit or delete User A's product listing.
4. **Chat Eavesdropping**: User C attempts to read messages from a private conversation between User A and User B.
5. **Unauthenticated Read of Reports**: User attempts to inspect moderation tickets or user complaints.
6. **Denial of Wallet Injection**: Injected 10MB payload in product title or description.
7. **Orphaned Message Write**: Attacker posts a message directly into a non-existent conversation or a conversation they do not belong to.
8. **Timestamp Tampering**: Client supplies a falsified `createdAt` from 1999 to manipulate chronological sorting.
9. **Immutability Breach**: Seller attempts to alter `sellerId` to pass off counterfeit listings.
10. **State Shortcutting in Reports**: Non-admin user attempts to alter report `status` from `open` to `resolved`.
11. **Path Variable ID Poisoning**: Attacker uses directory traversal characters or 1000-character string as document ID.
12. **Blanket Query Scraping**: Malicious client queries all users or all conversations without filtering by their own UID.
